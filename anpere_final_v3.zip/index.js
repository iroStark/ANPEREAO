// server/index.ts
import "dotenv/config";
import express3 from "express";
import session from "express-session";
import createMemoryStore from "memorystore";

// server/routes.ts
import { createServer } from "http";
import bcrypt from "bcryptjs";
import { z as z2 } from "zod";

// shared/schema.ts
import { mysqlTable, text, varchar, timestamp, int, boolean } from "drizzle-orm/mysql-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
var users = mysqlTable("users", {
  id: varchar("id", { length: 36 }).primaryKey(),
  username: text("username").notNull(),
  email: text("email"),
  password: text("password").notNull(),
  role: varchar("role", { length: 20 }).notNull().default("viewer"),
  // 'admin', 'editor', 'viewer'
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
  lastLoginAt: timestamp("last_login_at"),
  updatedAt: timestamp("updated_at").defaultNow()
});
var insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var aboutContent = mysqlTable("about_content", {
  id: varchar("id", { length: 36 }).primaryKey(),
  section: varchar("section", { length: 50 }).notNull(),
  // 'mission', 'vision', 'values', 'history'
  title: text("title").notNull(),
  content: text("content").notNull(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var insertAboutContentSchema = createInsertSchema(aboutContent).omit({
  id: true,
  updatedAt: true
});
var timelineEvents = mysqlTable("timeline_events", {
  id: varchar("id", { length: 36 }).primaryKey(),
  year: varchar("year", { length: 10 }).notNull(),
  event: text("event").notNull(),
  description: text("description").notNull(),
  details: text("details"),
  // Detalhes expandidos para o modal
  imageUrl: text("image_url"),
  // URL da imagem opcional
  order: int("order").default(0),
  // Ordem de exibição
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var insertTimelineEventSchema = createInsertSchema(timelineEvents).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var legislation = mysqlTable("legislation", {
  id: varchar("id", { length: 36 }).primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: varchar("category", { length: 50 }).notNull(),
  // 'Lei Principal', 'Regulamento', 'Código', 'Decreto', 'Estatuto'
  year: varchar("year", { length: 4 }).notNull(),
  icon: varchar("icon", { length: 50 }).notNull(),
  // lucide icon name
  content: text("content"),
  // Conteúdo HTML/texto para visualização visual
  fileUrl: text("file_url"),
  // URL do arquivo PDF (opcional)
  publishedAt: timestamp("published_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var insertLegislationSchema = createInsertSchema(legislation).omit({
  id: true,
  publishedAt: true,
  updatedAt: true
});
var publications = mysqlTable("publications", {
  id: varchar("id", { length: 36 }).primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: varchar("category", { length: 50 }).notNull(),
  // 'Plano', 'Relatório', 'Acta', etc.
  date: varchar("date", { length: 50 }).notNull(),
  // formatted date string
  fileUrl: text("file_url"),
  // URL to the document file
  downloadUrl: text("download_url"),
  // URL for downloading the file
  publishedAt: timestamp("published_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var insertPublicationSchema = createInsertSchema(publications).omit({
  id: true,
  publishedAt: true,
  updatedAt: true
});
var events = mysqlTable("events", {
  id: varchar("id", { length: 36 }).primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  date: varchar("date", { length: 50 }).notNull(),
  // formatted date string
  time: varchar("time", { length: 50 }).notNull(),
  // time range string
  location: text("location").notNull(),
  type: varchar("type", { length: 50 }).notNull(),
  // 'Conferência', 'Workshop', etc.
  capacity: varchar("capacity", { length: 20 }),
  // participant count/limit
  registrationUrl: text("registration_url"),
  // URL for registration
  publishedAt: timestamp("published_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var insertEventSchema = createInsertSchema(events).omit({
  id: true,
  publishedAt: true,
  updatedAt: true
});
var gallery = mysqlTable("gallery", {
  id: varchar("id", { length: 36 }).primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: varchar("type", { length: 10 }).notNull(),
  // 'image', 'video'
  date: varchar("date", { length: 50 }).notNull(),
  // formatted date string
  category: varchar("category", { length: 50 }).notNull(),
  // 'Evento', 'Palestra', etc.
  views: int("views").default(0),
  duration: varchar("duration", { length: 20 }),
  // for videos only
  thumbnail: text("thumbnail"),
  // URL to thumbnail image
  mediaUrl: text("media_url"),
  // URL to actual media file
  publishedAt: timestamp("published_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var insertGallerySchema = createInsertSchema(gallery).omit({
  id: true,
  publishedAt: true,
  updatedAt: true
});
var reports = mysqlTable("reports", {
  id: varchar("id", { length: 36 }).primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: varchar("type", { length: 20 }).notNull(),
  // 'monthly', 'quarterly', 'annual', 'special'
  status: varchar("status", { length: 20 }).notNull().default("draft"),
  // 'draft', 'published', 'archived'
  period: varchar("period", { length: 50 }).notNull(),
  // formatted period string
  fileUrl: text("file_url"),
  // URL to the report file
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var insertReportSchema = createInsertSchema(reports).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var settings = mysqlTable("settings", {
  id: varchar("id", { length: 36 }).primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
  description: text("description").notNull(),
  category: varchar("category", { length: 20 }).notNull(),
  // 'general', 'email', 'security', 'database', 'website'
  type: varchar("type", { length: 20 }).notNull(),
  // 'string', 'number', 'boolean', 'json'
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var insertSettingSchema = createInsertSchema(settings).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var members = mysqlTable("members", {
  id: varchar("id", { length: 36 }).primaryKey(),
  memberNumber: varchar("member_number", { length: 20 }),
  // Número de membro
  fullName: text("full_name").notNull(),
  birthDate: varchar("birth_date", { length: 50 }).notNull(),
  birthPlace: text("birth_place").notNull(),
  // Naturalidade
  nationality: varchar("nationality", { length: 50 }).notNull(),
  gender: varchar("gender", { length: 10 }).notNull(),
  // Sexo
  maritalStatus: varchar("marital_status", { length: 20 }).notNull(),
  // Estado Civil
  idDocument: varchar("id_document", { length: 50 }).notNull(),
  // B.I./Passaporte
  idIssueDate: varchar("id_issue_date", { length: 50 }).notNull(),
  idIssuePlace: text("id_issue_place").notNull(),
  fatherName: text("father_name").notNull(),
  motherName: text("mother_name").notNull(),
  occupation: text("occupation").notNull(),
  // Função que Exerce/exerceu
  phone: varchar("phone", { length: 20 }).notNull(),
  currentAddress: text("current_address").notNull(),
  // Residência Actual
  municipality: text("municipality").notNull(),
  // Município e Distrito
  workProvince: text("work_province").notNull(),
  // Província onde Trabalhou
  email: text("email").notNull(),
  photoUrl: text("photo_url"),
  // URL da foto
  otherInfo: text("other_info"),
  // Outros dados
  registrationDate: timestamp("registration_date").defaultNow(),
  status: varchar("status", { length: 20 }).notNull().default("pending"),
  // 'active', 'inactive', 'pending'
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var insertMemberSchema = createInsertSchema(members).omit({
  id: true,
  memberNumber: true,
  registrationDate: true,
  createdAt: true,
  updatedAt: true
}).extend({
  gender: z.enum(["Masculino", "Feminino"], {
    required_error: "Selecione o sexo"
  }),
  maritalStatus: z.enum(["Solteiro(a)", "Casado(a)", "Divorciado(a)", "Vi\xFAvo(a)"], {
    required_error: "Selecione o estado civil"
  })
});
var slideshow = mysqlTable("slideshow", {
  id: varchar("id", { length: 36 }).primaryKey(),
  title: text("title").notNull(),
  subtitle: text("subtitle"),
  description: text("description").notNull(),
  imageUrl: text("image_url").notNull(),
  // URL to the slide image
  order: int("order").notNull().default(0),
  // Order of display
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var insertSlideshowSchema = createInsertSchema(slideshow).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var activityPlan = mysqlTable("activity_plan", {
  id: varchar("id", { length: 36 }).primaryKey(),
  year: varchar("year", { length: 4 }).notNull(),
  // '2025'
  title: text("title").notNull().default("Plano de Atividades"),
  description: text("description"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var insertActivityPlanSchema = createInsertSchema(activityPlan).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var activityPlanItems = mysqlTable("activity_plan_items", {
  id: varchar("id", { length: 36 }).primaryKey(),
  planId: varchar("plan_id", { length: 36 }).notNull().references(() => activityPlan.id, { onDelete: "cascade" }),
  number: int("number").notNull(),
  // Número da atividade
  activity: text("activity").notNull(),
  // Nome da atividade
  date: text("date"),
  // Data ou período (ex: "Janeiro a Dezembro", "Trimestralmente")
  time: text("time"),
  // Hora ou período de tempo
  location: text("location"),
  // Local da atividade
  participants: text("participants"),
  // Participantes
  order: int("order").notNull().default(0),
  // Ordem de exibição
  parentId: varchar("parent_id", { length: 36 }),
  // Para sub-atividades (referência ao item pai)
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var insertActivityPlanItemSchema = createInsertSchema(activityPlanItems).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var contactMessages = mysqlTable("contact_messages", {
  id: varchar("id", { length: 36 }).primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var insertContactMessageSchema = createInsertSchema(contactMessages).omit({
  id: true,
  isRead: true,
  createdAt: true,
  updatedAt: true
});
var orgaosSociais = mysqlTable("orgaos_sociais", {
  id: varchar("id", { length: 36 }).primaryKey(),
  name: text("name").notNull(),
  position: varchar("position", { length: 100 }).notNull(),
  organType: varchar("organ_type", { length: 50 }).notNull(),
  // 'Assembleia Geral', 'Direcção', 'Conselho Fiscal'
  bio: text("bio"),
  photoUrl: text("photo_url"),
  email: text("email"),
  phone: varchar("phone", { length: 20 }),
  orderIndex: int("order_index").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});
var insertOrgaoSocialSchema = createInsertSchema(orgaosSociais).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});
var notifications = mysqlTable("notifications", {
  id: varchar("id", { length: 36 }).primaryKey(),
  type: varchar("type", { length: 50 }).notNull(),
  // 'member_registration', 'contact_message', etc.
  title: text("title").notNull(),
  message: text("message").notNull(),
  link: text("link"),
  // URL para a página relacionada
  isRead: boolean("is_read").default(false),
  relatedId: varchar("related_id", { length: 255 }),
  // ID do membro, mensagem, etc.
  createdAt: timestamp("created_at").defaultNow(),
  readAt: timestamp("read_at")
});
var insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
  readAt: true
});

// server/storage.ts
import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import { eq, asc, desc, and } from "drizzle-orm";
import { randomUUID } from "crypto";
var DatabaseStorage = class {
  db;
  constructor() {
    if (!process.env.DATABASE_URL) {
      throw new Error(
        "DATABASE_URL environment variable is not set. Please set it in your .env file with your MySQL connection string. "
      );
    }
    const pool = mysql.createPool({
      uri: process.env.DATABASE_URL,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0
    });
    this.db = drizzle(pool, { mode: "default" });
  }
  // User operations
  async getUser(id) {
    const result = await this.db.select().from(users).where(eq(users.id, id));
    return result[0];
  }
  async getUserByUsername(username) {
    const result = await this.db.select().from(users).where(eq(users.username, username));
    return result[0];
  }
  async createUser(user) {
    const id = randomUUID();
    const newUser = {
      ...user,
      id,
      role: user.role || "viewer",
      isActive: user.isActive ?? true,
      email: user.email || null,
      lastLoginAt: null,
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    };
    await this.db.insert(users).values(newUser);
    return newUser;
  }
  // About Content operations
  async getAboutContent() {
    return await this.db.select().from(aboutContent);
  }
  async getAboutContentBySection(section) {
    const result = await this.db.select().from(aboutContent).where(eq(aboutContent.section, section));
    return result[0];
  }
  async createAboutContent(content) {
    const id = randomUUID();
    const newContent = { ...content, id, updatedAt: /* @__PURE__ */ new Date() };
    await this.db.insert(aboutContent).values(newContent);
    return newContent;
  }
  async updateAboutContent(id, content) {
    await this.db.update(aboutContent).set({ ...content, updatedAt: /* @__PURE__ */ new Date() }).where(eq(aboutContent.id, id));
    return this.getAboutContentBySection(content.section || "") || this.db.select().from(aboutContent).where(eq(aboutContent.id, id)).then((res) => res[0]);
  }
  async deleteAboutContent(id) {
    const [result] = await this.db.delete(aboutContent).where(eq(aboutContent.id, id));
    return result.affectedRows > 0;
  }
  // Timeline Events operations
  async getAllTimelineEvents() {
    return await this.db.select().from(timelineEvents).where(eq(timelineEvents.isActive, true)).orderBy(asc(timelineEvents.order), desc(timelineEvents.year));
  }
  async getTimelineEvent(id) {
    const result = await this.db.select().from(timelineEvents).where(eq(timelineEvents.id, id));
    return result[0];
  }
  async createTimelineEvent(event) {
    const id = randomUUID();
    const newEvent = {
      ...event,
      id,
      details: event.details || null,
      imageUrl: event.imageUrl || null,
      order: event.order ?? 0,
      isActive: event.isActive ?? true,
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    };
    await this.db.insert(timelineEvents).values(newEvent);
    return newEvent;
  }
  async updateTimelineEvent(id, event) {
    await this.db.update(timelineEvents).set({ ...event, updatedAt: /* @__PURE__ */ new Date() }).where(eq(timelineEvents.id, id));
    return this.getTimelineEvent(id);
  }
  async deleteTimelineEvent(id) {
    const [result] = await this.db.delete(timelineEvents).where(eq(timelineEvents.id, id));
    return result.affectedRows > 0;
  }
  // Notifications operations
  async getAllNotifications() {
    return await this.db.select().from(notifications).orderBy(desc(notifications.createdAt));
  }
  async getUnreadNotificationsCount() {
    const result = await this.db.select().from(notifications).where(eq(notifications.isRead, false));
    return result.length;
  }
  async getNotification(id) {
    const result = await this.db.select().from(notifications).where(eq(notifications.id, id));
    return result[0];
  }
  async createNotification(notification) {
    const id = randomUUID();
    const newNotification = {
      ...notification,
      id,
      link: notification.link || null,
      relatedId: notification.relatedId || null,
      isRead: false,
      readAt: null,
      createdAt: /* @__PURE__ */ new Date()
    };
    await this.db.insert(notifications).values(newNotification);
    return newNotification;
  }
  async markNotificationAsRead(id) {
    await this.db.update(notifications).set({ isRead: true, readAt: /* @__PURE__ */ new Date() }).where(eq(notifications.id, id));
    return this.getNotification(id);
  }
  async markAllNotificationsAsRead() {
    const [result] = await this.db.update(notifications).set({ isRead: true, readAt: /* @__PURE__ */ new Date() }).where(eq(notifications.isRead, false));
    return result.affectedRows > 0;
  }
  async deleteNotification(id) {
    const [result] = await this.db.delete(notifications).where(eq(notifications.id, id));
    return result.affectedRows > 0;
  }
  // Legislation operations
  async getAllLegislation() {
    return await this.db.select().from(legislation);
  }
  async getLegislation(id) {
    const result = await this.db.select().from(legislation).where(eq(legislation.id, id));
    return result[0];
  }
  async createLegislation(leg) {
    const id = randomUUID();
    const newLegislation = {
      ...leg,
      id,
      content: leg.content || null,
      fileUrl: leg.fileUrl || null,
      publishedAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    };
    await this.db.insert(legislation).values(newLegislation);
    return newLegislation;
  }
  async updateLegislation(id, leg) {
    await this.db.update(legislation).set({ ...leg, updatedAt: /* @__PURE__ */ new Date() }).where(eq(legislation.id, id));
    return this.getLegislation(id);
  }
  async deleteLegislation(id) {
    const [result] = await this.db.delete(legislation).where(eq(legislation.id, id));
    return result.affectedRows > 0;
  }
  // Publication operations
  async getAllPublications() {
    return await this.db.select().from(publications);
  }
  async getPublication(id) {
    const result = await this.db.select().from(publications).where(eq(publications.id, id));
    return result[0];
  }
  async createPublication(pub) {
    const id = randomUUID();
    const newPublication = {
      ...pub,
      fileUrl: pub.fileUrl ?? null,
      downloadUrl: pub.downloadUrl ?? null,
      id,
      publishedAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    };
    await this.db.insert(publications).values(newPublication);
    return newPublication;
  }
  async updatePublication(id, pub) {
    await this.db.update(publications).set({ ...pub, updatedAt: /* @__PURE__ */ new Date() }).where(eq(publications.id, id));
    return this.getPublication(id);
  }
  async deletePublication(id) {
    const [result] = await this.db.delete(publications).where(eq(publications.id, id));
    return result.affectedRows > 0;
  }
  // Event operations
  async getAllEvents() {
    return await this.db.select().from(events);
  }
  async getEvent(id) {
    const result = await this.db.select().from(events).where(eq(events.id, id));
    return result[0];
  }
  async createEvent(event) {
    const id = randomUUID();
    const newEvent = {
      ...event,
      capacity: event.capacity ?? null,
      registrationUrl: event.registrationUrl ?? null,
      id,
      publishedAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    };
    await this.db.insert(events).values(newEvent);
    return newEvent;
  }
  async updateEvent(id, event) {
    await this.db.update(events).set({ ...event, updatedAt: /* @__PURE__ */ new Date() }).where(eq(events.id, id));
    return this.getEvent(id);
  }
  async deleteEvent(id) {
    const [result] = await this.db.delete(events).where(eq(events.id, id));
    return result.affectedRows > 0;
  }
  // Gallery operations
  async getAllGallery() {
    return await this.db.select().from(gallery);
  }
  async getGalleryItem(id) {
    const result = await this.db.select().from(gallery).where(eq(gallery.id, id));
    return result[0];
  }
  async createGalleryItem(item) {
    const id = randomUUID();
    const newItem = {
      ...item,
      views: item.views ?? 0,
      duration: item.duration ?? null,
      thumbnail: item.thumbnail ?? null,
      mediaUrl: item.mediaUrl ?? null,
      id,
      publishedAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    };
    await this.db.insert(gallery).values(newItem);
    return newItem;
  }
  async updateGalleryItem(id, item) {
    await this.db.update(gallery).set({ ...item, updatedAt: /* @__PURE__ */ new Date() }).where(eq(gallery.id, id));
    return this.getGalleryItem(id);
  }
  async deleteGalleryItem(id) {
    const [result] = await this.db.delete(gallery).where(eq(gallery.id, id));
    return result.affectedRows > 0;
  }
  // User management operations
  async getAllUsers() {
    return await this.db.select().from(users);
  }
  async updateUser(id, user) {
    await this.db.update(users).set({ ...user, updatedAt: /* @__PURE__ */ new Date() }).where(eq(users.id, id));
    return this.getUser(id);
  }
  async deleteUser(id) {
    const [result] = await this.db.delete(users).where(eq(users.id, id));
    return result.affectedRows > 0;
  }
  // Report operations
  async getAllReports() {
    return await this.db.select().from(reports);
  }
  async getReport(id) {
    const result = await this.db.select().from(reports).where(eq(reports.id, id));
    return result[0];
  }
  async createReport(report) {
    const id = randomUUID();
    const newReport = {
      ...report,
      id,
      fileUrl: report.fileUrl || null,
      status: report.status || "draft",
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    };
    await this.db.insert(reports).values(newReport);
    return newReport;
  }
  async updateReport(id, report) {
    await this.db.update(reports).set({ ...report, updatedAt: /* @__PURE__ */ new Date() }).where(eq(reports.id, id));
    return this.getReport(id);
  }
  async deleteReport(id) {
    const [result] = await this.db.delete(reports).where(eq(reports.id, id));
    return result.affectedRows > 0;
  }
  // Setting operations
  async getAllSettings() {
    return await this.db.select().from(settings);
  }
  async getSetting(id) {
    const result = await this.db.select().from(settings).where(eq(settings.id, id));
    return result[0];
  }
  async createSetting(setting) {
    const id = randomUUID();
    const newSetting = { ...setting, id, createdAt: /* @__PURE__ */ new Date(), updatedAt: /* @__PURE__ */ new Date() };
    await this.db.insert(settings).values(newSetting);
    return newSetting;
  }
  async updateSetting(id, setting) {
    await this.db.update(settings).set({ ...setting, updatedAt: /* @__PURE__ */ new Date() }).where(eq(settings.id, id));
    return this.getSetting(id);
  }
  async deleteSetting(id) {
    const [result] = await this.db.delete(settings).where(eq(settings.id, id));
    return result.affectedRows > 0;
  }
  // Member operations
  async getAllMembers() {
    return await this.db.select().from(members);
  }
  async getMember(id) {
    const result = await this.db.select().from(members).where(eq(members.id, id));
    return result[0];
  }
  async createMember(member) {
    const year = (/* @__PURE__ */ new Date()).getFullYear();
    const existingMembers = await this.db.select().from(members);
    const memberCount = existingMembers.length + 1;
    const memberNumber = `${String(memberCount).padStart(4, "0")}/${year}`;
    const id = randomUUID();
    const newMember = {
      ...member,
      id,
      memberNumber,
      photoUrl: member.photoUrl || null,
      otherInfo: member.otherInfo || null,
      status: member.status || "pending",
      registrationDate: /* @__PURE__ */ new Date(),
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    };
    await this.db.insert(members).values(newMember);
    return newMember;
  }
  async updateMember(id, member) {
    await this.db.update(members).set({ ...member, updatedAt: /* @__PURE__ */ new Date() }).where(eq(members.id, id));
    return this.getMember(id);
  }
  async deleteMember(id) {
    const [result] = await this.db.delete(members).where(eq(members.id, id));
    return result.affectedRows > 0;
  }
  // Slideshow operations
  async getAllSlideshow() {
    return await this.db.select().from(slideshow).orderBy(asc(slideshow.order));
  }
  async getSlideshow(id) {
    const result = await this.db.select().from(slideshow).where(eq(slideshow.id, id));
    return result[0];
  }
  async createSlideshow(item) {
    const id = randomUUID();
    const newItem = {
      ...item,
      id,
      subtitle: item.subtitle || null,
      order: item.order ?? 0,
      isActive: item.isActive ?? true,
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    };
    await this.db.insert(slideshow).values(newItem);
    return newItem;
  }
  async updateSlideshow(id, item) {
    await this.db.update(slideshow).set({ ...item, updatedAt: /* @__PURE__ */ new Date() }).where(eq(slideshow.id, id));
    return this.getSlideshow(id);
  }
  async deleteSlideshow(id) {
    const [result] = await this.db.delete(slideshow).where(eq(slideshow.id, id));
    return result.affectedRows > 0;
  }
  // Activity Plan operations
  async getActiveActivityPlan() {
    const result = await this.db.select().from(activityPlan).where(eq(activityPlan.isActive, true)).limit(1);
    if (result.length === 0) return void 0;
    const plan = result[0];
    const items = await this.getActivityPlanItems(plan.id);
    return { ...plan, items };
  }
  async getAllActivityPlans() {
    return await this.db.select().from(activityPlan).orderBy(asc(activityPlan.year));
  }
  async getActivityPlan(id) {
    const result = await this.db.select().from(activityPlan).where(eq(activityPlan.id, id));
    if (result.length === 0) return void 0;
    const plan = result[0];
    const items = await this.getActivityPlanItems(plan.id);
    return { ...plan, items };
  }
  async createActivityPlan(plan) {
    const id = randomUUID();
    const newPlan = {
      ...plan,
      id,
      title: plan.title || "Plano de Atividades",
      description: plan.description || null,
      isActive: plan.isActive ?? true,
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    };
    await this.db.insert(activityPlan).values(newPlan);
    return newPlan;
  }
  async updateActivityPlan(id, plan) {
    await this.db.update(activityPlan).set({ ...plan, updatedAt: /* @__PURE__ */ new Date() }).where(eq(activityPlan.id, id));
    const result = await this.db.select().from(activityPlan).where(eq(activityPlan.id, id));
    return result[0];
  }
  async deleteActivityPlan(id) {
    const [result] = await this.db.delete(activityPlan).where(eq(activityPlan.id, id));
    return result.affectedRows > 0;
  }
  // Activity Plan Items operations (helper methods)
  async getActivityPlanItems(planId) {
    return await this.db.select().from(activityPlanItems).where(eq(activityPlanItems.planId, planId)).orderBy(asc(activityPlanItems.order));
  }
  async createActivityPlanItem(item) {
    const id = randomUUID();
    const newItem = {
      ...item,
      id,
      date: item.date || null,
      time: item.time || null,
      location: item.location || null,
      participants: item.participants || null,
      order: item.order ?? 0,
      parentId: item.parentId || null,
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    };
    await this.db.insert(activityPlanItems).values(newItem);
    return newItem;
  }
  async updateActivityPlanItem(id, item) {
    await this.db.update(activityPlanItems).set({ ...item, updatedAt: /* @__PURE__ */ new Date() }).where(eq(activityPlanItems.id, id));
    const result = await this.db.select().from(activityPlanItems).where(eq(activityPlanItems.id, id));
    return result[0];
  }
  async deleteActivityPlanItem(id) {
    const [result] = await this.db.delete(activityPlanItems).where(eq(activityPlanItems.id, id));
    return result.affectedRows > 0;
  }
  // Órgãos Sociais operations
  async getAllOrgaosSociais() {
    return await this.db.select().from(orgaosSociais).orderBy(asc(orgaosSociais.orderIndex));
  }
  async getOrgaoSocial(id) {
    const result = await this.db.select().from(orgaosSociais).where(eq(orgaosSociais.id, id));
    return result[0];
  }
  async getOrgaosSociaisByType(organType) {
    return await this.db.select().from(orgaosSociais).where(and(eq(orgaosSociais.organType, organType), eq(orgaosSociais.isActive, true))).orderBy(asc(orgaosSociais.orderIndex));
  }
  async createOrgaoSocial(orgao) {
    const id = randomUUID();
    const newOrgao = {
      ...orgao,
      id,
      bio: orgao.bio || null,
      photoUrl: orgao.photoUrl || null,
      email: orgao.email || null,
      phone: orgao.phone || null,
      orderIndex: orgao.orderIndex ?? 0,
      isActive: orgao.isActive ?? true,
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    };
    await this.db.insert(orgaosSociais).values(newOrgao);
    return newOrgao;
  }
  async updateOrgaoSocial(id, orgao) {
    await this.db.update(orgaosSociais).set({ ...orgao, updatedAt: /* @__PURE__ */ new Date() }).where(eq(orgaosSociais.id, id));
    return this.getOrgaoSocial(id);
  }
  async deleteOrgaoSocial(id) {
    const [result] = await this.db.delete(orgaosSociais).where(eq(orgaosSociais.id, id));
    return result.affectedRows > 0;
  }
  // Contact Messages operations
  async getAllContactMessages() {
    try {
      const messages = await this.db.select().from(contactMessages).orderBy(desc(contactMessages.createdAt));
      return messages;
    } catch (error) {
      console.error("Error fetching contact messages:", error);
      throw error;
    }
  }
  async getContactMessage(id) {
    const result = await this.db.select().from(contactMessages).where(eq(contactMessages.id, id));
    return result[0];
  }
  async createContactMessage(message) {
    const id = randomUUID();
    const newMessage = {
      ...message,
      id,
      phone: message.phone || null,
      isRead: false,
      createdAt: /* @__PURE__ */ new Date(),
      updatedAt: /* @__PURE__ */ new Date()
    };
    await this.db.insert(contactMessages).values(newMessage);
    return newMessage;
  }
  async updateContactMessage(id, message) {
    await this.db.update(contactMessages).set({ ...message, updatedAt: /* @__PURE__ */ new Date() }).where(eq(contactMessages.id, id));
    return this.getContactMessage(id);
  }
  async deleteContactMessage(id) {
    try {
      const [result] = await this.db.delete(contactMessages).where(eq(contactMessages.id, id));
      return result.affectedRows > 0;
    } catch (error) {
      console.error("Error deleting contact message:", error);
      return false;
    }
  }
};
var storage = new DatabaseStorage();

// server/routes.ts
import multer from "multer";
import path from "path";
import fs from "fs";
import express from "express";
var loginSchema = z2.object({
  username: z2.string().min(1, "Username is required"),
  password: z2.string().min(1, "Password is required")
});
var requireAuth = async (req, res, next) => {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({ error: "Authentication required" });
  }
  try {
    const user = await storage.getUser(req.session.userId);
    if (!user) {
      req.session.destroy(() => {
      });
      return res.status(401).json({ error: "User not found" });
    }
    req.user = { id: user.id, username: user.username };
    next();
  } catch (error) {
    console.error("Auth middleware error:", error);
    res.status(500).json({ error: "Authentication error" });
  }
};
async function initializeAdmin() {
  const adminUsername = process.env.ADMIN_USERNAME || "admin";
  const adminPassword = process.env.ADMIN_PASSWORD || "admin123";
  try {
    const existingAdmin = await storage.getUserByUsername(adminUsername);
    if (!existingAdmin) {
      const hashedPassword = await bcrypt.hash(adminPassword, 10);
      await storage.createUser({
        username: adminUsername,
        password: hashedPassword,
        role: "admin",
        isActive: true
      });
      console.log(`Admin user created with username: ${adminUsername}`);
    }
  } catch (error) {
    console.error("Failed to initialize admin user:", error);
  }
}
async function registerRoutes(app2) {
  await initializeAdmin();
  const uploadDir = path.join(process.cwd(), "uploads");
  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
  }
  const multerStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
      cb(null, file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname));
    }
  });
  const upload = multer({
    storage: multerStorage,
    limits: {
      fileSize: 50 * 1024 * 1024
      // 50MB limit (aumentado para vídeos)
    },
    fileFilter: (req, file, cb) => {
      const allowedTypes = /jpeg|jpg|png|gif|webp|mp4|mov|avi|webm|mkv/;
      const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
      const mimetype = allowedTypes.test(file.mimetype);
      if (mimetype && extname) {
        return cb(null, true);
      } else {
        cb(new Error("Tipo de arquivo n\xE3o suportado. Use apenas imagens (JPG, PNG, GIF, WEBP) ou v\xEDdeos (MP4, MOV, AVI, WEBM, MKV)."));
      }
    }
  });
  app2.use("/uploads", express.static(uploadDir));
  const attachedAssetsDir = path.join(process.cwd(), "attached_assets");
  if (fs.existsSync(attachedAssetsDir)) {
    app2.use("/attached_assets", express.static(attachedAssetsDir));
  }
  app2.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      req.session.userId = user.id;
      res.json({
        success: true,
        user: { id: user.id, username: user.username }
      });
    } catch (error) {
      if (error instanceof z2.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      console.error("Login error:", error);
      res.status(500).json({ error: "Login failed" });
    }
  });
  app2.post("/api/auth/logout", (req, res) => {
    req.session.destroy((error) => {
      if (error) {
        console.error("Logout error:", error);
        return res.status(500).json({ error: "Logout failed" });
      }
      res.json({ success: true });
    });
  });
  app2.get("/api/auth/me", requireAuth, (req, res) => {
    res.json({ user: req.user });
  });
  app2.get("/api/admin/about", requireAuth, async (req, res) => {
    try {
      const content = await storage.getAboutContent();
      res.json(content);
    } catch (error) {
      console.error("Error fetching about content:", error);
      res.status(500).json({ error: "Failed to fetch about content" });
    }
  });
  app2.post("/api/admin/about", requireAuth, async (req, res) => {
    try {
      const content = await storage.createAboutContent(req.body);
      res.status(201).json(content);
    } catch (error) {
      console.error("Error creating about content:", error);
      res.status(500).json({ error: "Failed to create about content" });
    }
  });
  app2.put("/api/admin/about/:id", requireAuth, async (req, res) => {
    try {
      const content = await storage.updateAboutContent(req.params.id, req.body);
      if (!content) {
        return res.status(404).json({ error: "About content not found" });
      }
      res.json(content);
    } catch (error) {
      console.error("Error updating about content:", error);
      res.status(500).json({ error: "Failed to update about content" });
    }
  });
  app2.delete("/api/admin/about/:id", requireAuth, async (req, res) => {
    try {
      const success = await storage.deleteAboutContent(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "About content not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting about content:", error);
      res.status(500).json({ error: "Failed to delete about content" });
    }
  });
  app2.get("/api/admin/timeline-events", requireAuth, async (req, res) => {
    try {
      const events2 = await storage.getAllTimelineEvents();
      res.json(events2);
    } catch (error) {
      console.error("Error fetching timeline events:", error);
      res.status(500).json({ error: "Failed to fetch timeline events" });
    }
  });
  app2.get("/api/admin/timeline-events/:id", requireAuth, async (req, res) => {
    try {
      const event = await storage.getTimelineEvent(req.params.id);
      if (!event) {
        return res.status(404).json({ error: "Timeline event not found" });
      }
      res.json(event);
    } catch (error) {
      console.error("Error fetching timeline event:", error);
      res.status(500).json({ error: "Failed to fetch timeline event" });
    }
  });
  app2.post("/api/admin/timeline-events", requireAuth, upload.single("image"), async (req, res) => {
    try {
      const eventData = { ...req.body };
      if (req.file) {
        eventData.imageUrl = `/uploads/${req.file.filename}`;
      }
      if (eventData.order !== void 0) {
        eventData.order = parseInt(eventData.order, 10);
      }
      if (eventData.isActive !== void 0) {
        eventData.isActive = eventData.isActive === "true" || eventData.isActive === true;
      }
      const event = await storage.createTimelineEvent(eventData);
      res.status(201).json(event);
    } catch (error) {
      console.error("Error creating timeline event:", error);
      res.status(500).json({ error: "Failed to create timeline event" });
    }
  });
  app2.put("/api/admin/timeline-events/:id", requireAuth, upload.single("image"), async (req, res) => {
    try {
      const updateData = { ...req.body };
      if (req.file) {
        updateData.imageUrl = `/uploads/${req.file.filename}`;
      }
      if (updateData.order !== void 0) {
        updateData.order = parseInt(updateData.order, 10);
      }
      if (updateData.isActive !== void 0) {
        updateData.isActive = updateData.isActive === "true" || updateData.isActive === true;
      }
      const event = await storage.updateTimelineEvent(req.params.id, updateData);
      if (!event) {
        return res.status(404).json({ error: "Timeline event not found" });
      }
      res.json(event);
    } catch (error) {
      console.error("Error updating timeline event:", error);
      res.status(500).json({ error: "Failed to update timeline event" });
    }
  });
  app2.delete("/api/admin/timeline-events/:id", requireAuth, async (req, res) => {
    try {
      const success = await storage.deleteTimelineEvent(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Timeline event not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting timeline event:", error);
      res.status(500).json({ error: "Failed to delete timeline event" });
    }
  });
  app2.get("/api/timeline-events", async (req, res) => {
    try {
      const events2 = await storage.getAllTimelineEvents();
      res.json(events2);
    } catch (error) {
      console.error("Error fetching timeline events:", error);
      res.status(500).json({ error: "Failed to fetch timeline events" });
    }
  });
  app2.get("/api/admin/notifications", requireAuth, async (req, res) => {
    try {
      const notifications2 = await storage.getAllNotifications();
      res.json(notifications2);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ error: "Failed to fetch notifications" });
    }
  });
  app2.get("/api/admin/notifications/unread-count", requireAuth, async (req, res) => {
    try {
      const count = await storage.getUnreadNotificationsCount();
      res.json({ count });
    } catch (error) {
      console.error("Error fetching unread notifications count:", error);
      res.status(500).json({ error: "Failed to fetch unread notifications count" });
    }
  });
  app2.put("/api/admin/notifications/:id/read", requireAuth, async (req, res) => {
    try {
      const notification = await storage.markNotificationAsRead(req.params.id);
      if (!notification) {
        return res.status(404).json({ error: "Notification not found" });
      }
      res.json(notification);
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ error: "Failed to mark notification as read" });
    }
  });
  app2.put("/api/admin/notifications/read-all", requireAuth, async (req, res) => {
    try {
      const success = await storage.markAllNotificationsAsRead();
      res.json({ success });
    } catch (error) {
      console.error("Error marking all notifications as read:", error);
      res.status(500).json({ error: "Failed to mark all notifications as read" });
    }
  });
  app2.delete("/api/admin/notifications/:id", requireAuth, async (req, res) => {
    try {
      const success = await storage.deleteNotification(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Notification not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting notification:", error);
      res.status(500).json({ error: "Failed to delete notification" });
    }
  });
  app2.get("/api/admin/legislation", requireAuth, async (req, res) => {
    try {
      const legislation2 = await storage.getAllLegislation();
      res.json(legislation2);
    } catch (error) {
      console.error("Error fetching legislation:", error);
      res.status(500).json({ error: "Failed to fetch legislation" });
    }
  });
  app2.post("/api/admin/legislation", requireAuth, async (req, res) => {
    try {
      const legislation2 = await storage.createLegislation(req.body);
      res.status(201).json(legislation2);
    } catch (error) {
      console.error("Error creating legislation:", error);
      res.status(500).json({ error: "Failed to create legislation" });
    }
  });
  app2.put("/api/admin/legislation/:id", requireAuth, async (req, res) => {
    try {
      const legislation2 = await storage.updateLegislation(req.params.id, req.body);
      if (!legislation2) {
        return res.status(404).json({ error: "Legislation not found" });
      }
      res.json(legislation2);
    } catch (error) {
      console.error("Error updating legislation:", error);
      res.status(500).json({ error: "Failed to update legislation" });
    }
  });
  app2.delete("/api/admin/legislation/:id", requireAuth, async (req, res) => {
    try {
      const success = await storage.deleteLegislation(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Legislation not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting legislation:", error);
      res.status(500).json({ error: "Failed to delete legislation" });
    }
  });
  app2.get("/api/admin/publications", requireAuth, async (req, res) => {
    try {
      const publications2 = await storage.getAllPublications();
      res.json(publications2);
    } catch (error) {
      console.error("Error fetching publications:", error);
      res.status(500).json({ error: "Failed to fetch publications" });
    }
  });
  app2.post("/api/admin/publications", requireAuth, async (req, res) => {
    try {
      const publication = await storage.createPublication(req.body);
      res.status(201).json(publication);
    } catch (error) {
      console.error("Error creating publication:", error);
      res.status(500).json({ error: "Failed to create publication" });
    }
  });
  app2.put("/api/admin/publications/:id", requireAuth, async (req, res) => {
    try {
      const publication = await storage.updatePublication(req.params.id, req.body);
      if (!publication) {
        return res.status(404).json({ error: "Publication not found" });
      }
      res.json(publication);
    } catch (error) {
      console.error("Error updating publication:", error);
      res.status(500).json({ error: "Failed to update publication" });
    }
  });
  app2.delete("/api/admin/publications/:id", requireAuth, async (req, res) => {
    try {
      const success = await storage.deletePublication(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Publication not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting publication:", error);
      res.status(500).json({ error: "Failed to delete publication" });
    }
  });
  app2.get("/api/admin/events", requireAuth, async (req, res) => {
    try {
      const events2 = await storage.getAllEvents();
      res.json(events2);
    } catch (error) {
      console.error("Error fetching events:", error);
      res.status(500).json({ error: "Failed to fetch events" });
    }
  });
  app2.post("/api/admin/events", requireAuth, async (req, res) => {
    try {
      const event = await storage.createEvent(req.body);
      res.status(201).json(event);
    } catch (error) {
      console.error("Error creating event:", error);
      res.status(500).json({ error: "Failed to create event" });
    }
  });
  app2.put("/api/admin/events/:id", requireAuth, async (req, res) => {
    try {
      const event = await storage.updateEvent(req.params.id, req.body);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
      res.json(event);
    } catch (error) {
      console.error("Error updating event:", error);
      res.status(500).json({ error: "Failed to update event" });
    }
  });
  app2.delete("/api/admin/events/:id", requireAuth, async (req, res) => {
    try {
      const success = await storage.deleteEvent(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Event not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting event:", error);
      res.status(500).json({ error: "Failed to delete event" });
    }
  });
  app2.get("/api/admin/gallery", requireAuth, async (req, res) => {
    try {
      const gallery2 = await storage.getAllGallery();
      res.json(gallery2);
    } catch (error) {
      console.error("Error fetching gallery:", error);
      res.status(500).json({ error: "Failed to fetch gallery" });
    }
  });
  app2.post("/api/admin/gallery", requireAuth, async (req, res) => {
    try {
      const item = await storage.createGalleryItem(req.body);
      res.status(201).json(item);
    } catch (error) {
      console.error("Error creating gallery item:", error);
      res.status(500).json({ error: "Failed to create gallery item" });
    }
  });
  app2.put("/api/admin/gallery/:id", requireAuth, async (req, res) => {
    try {
      const item = await storage.updateGalleryItem(req.params.id, req.body);
      if (!item) {
        return res.status(404).json({ error: "Gallery item not found" });
      }
      res.json(item);
    } catch (error) {
      console.error("Error updating gallery item:", error);
      res.status(500).json({ error: "Failed to update gallery item" });
    }
  });
  app2.delete("/api/admin/gallery/:id", requireAuth, async (req, res) => {
    try {
      const success = await storage.deleteGalleryItem(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Gallery item not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting gallery item:", error);
      res.status(500).json({ error: "Failed to delete gallery item" });
    }
  });
  app2.get("/api/slideshow", async (req, res) => {
    try {
      const slides = await storage.getAllSlideshow();
      const activeSlides = slides.filter((slide) => slide.isActive).sort((a, b) => a.order - b.order);
      res.json(activeSlides);
    } catch (error) {
      console.error("Error fetching slideshow:", error);
      res.json([]);
    }
  });
  app2.get("/api/activity-plan", async (req, res) => {
    try {
      const plan = await storage.getActiveActivityPlan();
      if (!plan) {
        return res.json(null);
      }
      res.json(plan);
    } catch (error) {
      console.error("Error fetching activity plan:", error);
      res.json(null);
    }
  });
  app2.get("/api/activity-plans", async (req, res) => {
    try {
      const plans = await storage.getAllActivityPlans();
      res.json(plans);
    } catch (error) {
      console.error("Error fetching activity plans:", error);
      res.json([]);
    }
  });
  app2.get("/api/activity-plan/:id", async (req, res) => {
    try {
      const plan = await storage.getActivityPlan(req.params.id);
      if (!plan) {
        return res.status(404).json({ error: "Activity plan not found" });
      }
      res.json(plan);
    } catch (error) {
      console.error("Error fetching activity plan:", error);
      res.status(500).json({ error: "Failed to fetch activity plan" });
    }
  });
  app2.get("/api/admin/slideshow", requireAuth, async (req, res) => {
    try {
      const slides = await storage.getAllSlideshow();
      res.json(slides);
    } catch (error) {
      console.error("Error fetching slideshow:", error);
      res.status(500).json({ error: "Failed to fetch slideshow" });
    }
  });
  app2.get("/api/admin/slideshow/:id", requireAuth, async (req, res) => {
    try {
      const slide = await storage.getSlideshow(req.params.id);
      if (!slide) {
        return res.status(404).json({ error: "Slide not found" });
      }
      res.json(slide);
    } catch (error) {
      console.error("Error fetching slide:", error);
      res.status(500).json({ error: "Failed to fetch slide" });
    }
  });
  app2.post("/api/admin/slideshow", requireAuth, upload.single("image"), async (req, res) => {
    try {
      let imageUrl = req.body.imageUrl;
      if (req.file) {
        imageUrl = `/uploads/${req.file.filename}`;
      }
      const slideData = {
        ...req.body,
        imageUrl,
        order: req.body.order ? parseInt(req.body.order, 10) : 0,
        isActive: req.body.isActive === "true" || req.body.isActive === true
      };
      const slide = await storage.createSlideshow(slideData);
      res.status(201).json(slide);
    } catch (error) {
      console.error("Error creating slide:", error);
      res.status(500).json({ error: "Failed to create slide" });
    }
  });
  app2.put("/api/admin/slideshow/:id", requireAuth, upload.single("image"), async (req, res) => {
    try {
      const updateData = { ...req.body };
      if (req.file) {
        updateData.imageUrl = `/uploads/${req.file.filename}`;
      }
      if (updateData.order !== void 0) {
        updateData.order = parseInt(updateData.order, 10);
      }
      if (updateData.isActive !== void 0) {
        updateData.isActive = updateData.isActive === "true" || updateData.isActive === true;
      }
      const slide = await storage.updateSlideshow(req.params.id, updateData);
      if (!slide) {
        return res.status(404).json({ error: "Slide not found" });
      }
      res.json(slide);
    } catch (error) {
      console.error("Error updating slide:", error);
      res.status(500).json({ error: "Failed to update slide" });
    }
  });
  app2.delete("/api/admin/slideshow/:id", requireAuth, async (req, res) => {
    try {
      const success = await storage.deleteSlideshow(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Slide not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting slide:", error);
      res.status(500).json({ error: "Failed to delete slide" });
    }
  });
  app2.get("/api/admin/activity-plan", requireAuth, async (req, res) => {
    try {
      const plans = await storage.getAllActivityPlans();
      res.json(plans);
    } catch (error) {
      console.error("Error fetching activity plans:", error);
      res.status(500).json({ error: "Failed to fetch activity plans" });
    }
  });
  app2.get("/api/admin/activity-plan/:id", requireAuth, async (req, res) => {
    try {
      const plan = await storage.getActivityPlan(req.params.id);
      if (!plan) {
        return res.status(404).json({ error: "Activity plan not found" });
      }
      res.json(plan);
    } catch (error) {
      console.error("Error fetching activity plan:", error);
      res.status(500).json({ error: "Failed to fetch activity plan" });
    }
  });
  app2.post("/api/admin/activity-plan", requireAuth, async (req, res) => {
    try {
      const plan = await storage.createActivityPlan(req.body);
      res.status(201).json(plan);
    } catch (error) {
      console.error("Error creating activity plan:", error);
      res.status(500).json({ error: "Failed to create activity plan" });
    }
  });
  app2.put("/api/admin/activity-plan/:id", requireAuth, async (req, res) => {
    try {
      const plan = await storage.updateActivityPlan(req.params.id, req.body);
      if (!plan) {
        return res.status(404).json({ error: "Activity plan not found" });
      }
      res.json(plan);
    } catch (error) {
      console.error("Error updating activity plan:", error);
      res.status(500).json({ error: "Failed to update activity plan" });
    }
  });
  app2.delete("/api/admin/activity-plan/:id", requireAuth, async (req, res) => {
    try {
      const success = await storage.deleteActivityPlan(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Activity plan not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting activity plan:", error);
      res.status(500).json({ error: "Failed to delete activity plan" });
    }
  });
  app2.get("/api/admin/activity-plan/:planId/items", requireAuth, async (req, res) => {
    try {
      const items = await storage.getActivityPlanItems(req.params.planId);
      res.json(items);
    } catch (error) {
      console.error("Error fetching activity plan items:", error);
      res.status(500).json({ error: "Failed to fetch activity plan items" });
    }
  });
  app2.post("/api/admin/activity-plan/:planId/items", requireAuth, async (req, res) => {
    try {
      const item = await storage.createActivityPlanItem({
        ...req.body,
        planId: req.params.planId
      });
      res.status(201).json(item);
    } catch (error) {
      console.error("Error creating activity plan item:", error);
      res.status(500).json({ error: "Failed to create activity plan item" });
    }
  });
  app2.put("/api/admin/activity-plan/:planId/items/:itemId", requireAuth, async (req, res) => {
    try {
      const item = await storage.updateActivityPlanItem(req.params.itemId, req.body);
      if (!item) {
        return res.status(404).json({ error: "Activity plan item not found" });
      }
      res.json(item);
    } catch (error) {
      console.error("Error updating activity plan item:", error);
      res.status(500).json({ error: "Failed to update activity plan item" });
    }
  });
  app2.delete("/api/admin/activity-plan/:planId/items/:itemId", requireAuth, async (req, res) => {
    try {
      const success = await storage.deleteActivityPlanItem(req.params.itemId);
      if (!success) {
        return res.status(404).json({ error: "Activity plan item not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting activity plan item:", error);
      res.status(500).json({ error: "Failed to delete activity plan item" });
    }
  });
  app2.get("/api/orgaos-sociais", async (req, res) => {
    try {
      const allOrgaos = await storage.getAllOrgaosSociais();
      const activeOrgaos = allOrgaos.filter((o) => o.isActive);
      res.json(activeOrgaos);
    } catch (error) {
      console.error("Error fetching orgaos sociais:", error);
      res.json([]);
    }
  });
  app2.get("/api/orgaos-sociais/:id", async (req, res) => {
    try {
      const orgao = await storage.getOrgaoSocial(req.params.id);
      if (!orgao) {
        return res.status(404).json({ error: "\xD3rg\xE3o social not found" });
      }
      res.json(orgao);
    } catch (error) {
      console.error("Error fetching orgao social:", error);
      res.status(500).json({ error: "Failed to fetch orgao social" });
    }
  });
  app2.get("/api/orgaos-sociais/tipo/:type", async (req, res) => {
    try {
      const orgaos = await storage.getOrgaosSociaisByType(req.params.type);
      res.json(orgaos);
    } catch (error) {
      console.error("Error fetching orgaos sociais by type:", error);
      res.json([]);
    }
  });
  app2.get("/api/admin/orgaos-sociais", requireAuth, async (req, res) => {
    try {
      const orgaos = await storage.getAllOrgaosSociais();
      res.json(orgaos);
    } catch (error) {
      console.error("Error fetching orgaos sociais:", error);
      res.status(500).json({ error: "Failed to fetch orgaos sociais" });
    }
  });
  app2.get("/api/admin/orgaos-sociais/:id", requireAuth, async (req, res) => {
    try {
      const orgao = await storage.getOrgaoSocial(req.params.id);
      if (!orgao) {
        return res.status(404).json({ error: "\xD3rg\xE3o social not found" });
      }
      res.json(orgao);
    } catch (error) {
      console.error("Error fetching orgao social:", error);
      res.status(500).json({ error: "Failed to fetch orgao social" });
    }
  });
  app2.post("/api/admin/orgaos-sociais", requireAuth, async (req, res) => {
    try {
      const orgao = await storage.createOrgaoSocial(req.body);
      res.status(201).json(orgao);
    } catch (error) {
      console.error("Error creating orgao social:", error);
      res.status(500).json({ error: "Failed to create orgao social" });
    }
  });
  app2.put("/api/admin/orgaos-sociais/:id", requireAuth, async (req, res) => {
    try {
      const orgao = await storage.updateOrgaoSocial(req.params.id, req.body);
      if (!orgao) {
        return res.status(404).json({ error: "\xD3rg\xE3o social not found" });
      }
      res.json(orgao);
    } catch (error) {
      console.error("Error updating orgao social:", error);
      res.status(500).json({ error: "Failed to update orgao social" });
    }
  });
  app2.delete("/api/admin/orgaos-sociais/:id", requireAuth, async (req, res) => {
    try {
      const success = await storage.deleteOrgaoSocial(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "\xD3rg\xE3o social not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting orgao social:", error);
      res.status(500).json({ error: "Failed to delete orgao social" });
    }
  });
  app2.post("/api/admin/upload", requireAuth, upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "Nenhum arquivo foi enviado" });
      }
      const fileUrl = `/uploads/${req.file.filename}`;
      res.json({
        success: true,
        filename: req.file.filename,
        originalName: req.file.originalname,
        size: req.file.size,
        url: fileUrl,
        type: req.file.mimetype
      });
    } catch (error) {
      console.error("Error uploading file:", error);
      res.status(500).json({ error: error.message || "Erro ao fazer upload do arquivo" });
    }
  });
  app2.post("/api/members/register", upload.single("photo"), async (req, res) => {
    try {
      const memberData = req.body;
      if (req.file) {
        memberData.photoUrl = `/uploads/${req.file.filename}`;
      }
      memberData.status = "pending";
      const member = await storage.createMember(memberData);
      try {
        console.log(`[POST /api/members/register] Criando notifica\xE7\xE3o para novo membro: ${member.id}`);
        const notification = await storage.createNotification({
          type: "member_registration",
          title: "Nova Candidatura de Membro",
          message: `${member.fullName} submeteu uma nova candidatura para se tornar membro da ANPERE.`,
          link: `/admin/members`,
          relatedId: member.id
        });
        console.log(`[POST /api/members/register] Notifica\xE7\xE3o criada com sucesso: ${notification.id}`);
      } catch (notificationError) {
        console.error("[POST /api/members/register] Erro ao criar notifica\xE7\xE3o para novo membro:", notificationError);
      }
      res.status(201).json(member);
    } catch (error) {
      console.error("Error registering member:", error);
      res.status(500).json({ error: "Failed to register member" });
    }
  });
  app2.get("/api/admin/members", requireAuth, async (req, res) => {
    try {
      const members2 = await storage.getAllMembers();
      res.json(members2);
    } catch (error) {
      console.error("Error fetching members:", error);
      res.status(500).json({ error: "Failed to fetch members" });
    }
  });
  app2.get("/api/admin/members/:id", requireAuth, async (req, res) => {
    try {
      const member = await storage.getMember(req.params.id);
      if (!member) {
        return res.status(404).json({ error: "Member not found" });
      }
      res.json(member);
    } catch (error) {
      console.error("Error fetching member:", error);
      res.status(500).json({ error: "Failed to fetch member" });
    }
  });
  app2.post("/api/admin/members", requireAuth, upload.single("photo"), async (req, res) => {
    try {
      const memberData = req.body;
      if (req.file) {
        memberData.photoUrl = `/uploads/${req.file.filename}`;
        console.log(`[POST /api/admin/members] Foto enviada: ${memberData.photoUrl}`);
      } else {
        memberData.photoUrl = memberData.photoUrl || "";
        console.log(`[POST /api/admin/members] Sem foto, photoUrl: ${memberData.photoUrl}`);
      }
      if (!memberData.status) {
        memberData.status = "pending";
      }
      console.log(`[POST /api/admin/members] Dados do membro:`, JSON.stringify(memberData, null, 2));
      const member = await storage.createMember(memberData);
      res.status(201).json(member);
    } catch (error) {
      console.error("Error creating member:", error);
      res.status(500).json({ error: "Failed to create member" });
    }
  });
  app2.put("/api/admin/members/:id", requireAuth, upload.single("photo"), async (req, res) => {
    try {
      const { sendEmail, ...updateData } = req.body;
      if (req.file) {
        updateData.photoUrl = `/uploads/${req.file.filename}`;
        console.log(`[PUT /api/admin/members/:id] Nova foto enviada: ${updateData.photoUrl}`);
      } else if (req.body.photoUrl && req.body.photoUrl.trim() !== "") {
        updateData.photoUrl = req.body.photoUrl;
        console.log(`[PUT /api/admin/members/:id] Preservando foto existente: ${updateData.photoUrl}`);
      } else {
        const currentMember = await storage.getMember(req.params.id);
        if (currentMember && currentMember.photoUrl) {
          updateData.photoUrl = currentMember.photoUrl;
          console.log(`[PUT /api/admin/members/:id] Preservando foto do banco: ${updateData.photoUrl}`);
        }
      }
      console.log(`[PUT /api/admin/members/:id] Dados a atualizar:`, JSON.stringify(updateData, null, 2));
      const member = await storage.updateMember(req.params.id, updateData);
      if (!member) {
        return res.status(404).json({ error: "Member not found" });
      }
      if (member.status === "active" && sendEmail) {
        try {
          const emailSubject = `Candidatura Aprovada - ANPERE`;
          const emailBody = `
Ol\xE1 ${member.fullName},

Temos o prazer de informar que a sua candidatura \xE0 Associa\xE7\xE3o Nacional dos Ex-Profissionais do Espectro R\xE1dio Electr\xF3nico (ANPERE) foi APROVADA!

Detalhes da sua candidatura:
- N\xFAmero de Membro: ${member.memberNumber}
- Data de Aprova\xE7\xE3o: ${(/* @__PURE__ */ new Date()).toLocaleDateString("pt-AO")}

A partir de agora, voc\xEA \xE9 um membro ativo da ANPERE e tem acesso a todos os benef\xEDcios e servi\xE7os da associa\xE7\xE3o.

Pr\xF3ximos passos:
- Voc\xEA receber\xE1 mais informa\xE7\xF5es sobre como aceder aos servi\xE7os da associa\xE7\xE3o
- Fique atento \xE0s comunica\xE7\xF5es sobre eventos e atividades
- Mantenha os seus dados atualizados no nosso sistema

Se tiver alguma d\xFAvida, n\xE3o hesite em contactar-nos atrav\xE9s de:
- Email: geral@anpere.ao
- Telefone: (ver contactos no website)

Bem-vindo \xE0 ANPERE!

Atenciosamente,
Equipa ANPERE
          `;
          console.log("\u{1F4E7} Email de aprova\xE7\xE3o a ser enviado:");
          console.log("Para:", member.email);
          console.log("Assunto:", emailSubject);
          console.log("Corpo:", emailBody);
        } catch (emailError) {
          console.error("Erro ao enviar email:", emailError);
        }
      }
      res.json(member);
    } catch (error) {
      console.error("Error updating member:", error);
      res.status(500).json({ error: "Failed to update member" });
    }
  });
  app2.delete("/api/admin/members/:id", requireAuth, async (req, res) => {
    try {
      const success = await storage.deleteMember(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Member not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting member:", error);
      res.status(500).json({ error: "Failed to delete member" });
    }
  });
  app2.get("/api/admin/users", requireAuth, async (req, res) => {
    try {
      const users2 = await storage.getAllUsers();
      res.json(users2);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ error: "Failed to fetch users" });
    }
  });
  app2.post("/api/admin/users", requireAuth, async (req, res) => {
    try {
      const { username, email, password, role, isActive } = req.body;
      const hashedPassword = await bcrypt.hash(password, 10);
      const user = await storage.createUser({
        username,
        email,
        password: hashedPassword,
        role: role || "viewer",
        isActive: isActive !== void 0 ? isActive : true
      });
      res.json(user);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ error: "Failed to create user" });
    }
  });
  app2.put("/api/admin/users/:id", requireAuth, async (req, res) => {
    try {
      const { username, email, password, role, isActive } = req.body;
      const updateData = { username, email, role, isActive };
      if (password) {
        updateData.password = await bcrypt.hash(password, 10);
      }
      const user = await storage.updateUser(req.params.id, updateData);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ error: "Failed to update user" });
    }
  });
  app2.delete("/api/admin/users/:id", requireAuth, async (req, res) => {
    try {
      const success = await storage.deleteUser(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ error: "Failed to delete user" });
    }
  });
  app2.get("/api/reports", async (req, res) => {
    try {
      const allReports = await storage.getAllReports();
      const publishedReports = allReports.filter((r) => r.status === "published");
      res.json(publishedReports);
    } catch (error) {
      console.error("Error fetching reports:", error);
      res.json([]);
    }
  });
  app2.get("/api/admin/reports", requireAuth, async (req, res) => {
    try {
      const reports2 = await storage.getAllReports();
      res.json(reports2);
    } catch (error) {
      console.error("Error fetching reports:", error);
      res.status(500).json({ error: "Failed to fetch reports" });
    }
  });
  app2.post("/api/admin/reports", requireAuth, async (req, res) => {
    try {
      const report = await storage.createReport(req.body);
      res.json(report);
    } catch (error) {
      console.error("Error creating report:", error);
      res.status(500).json({ error: "Failed to create report" });
    }
  });
  app2.put("/api/admin/reports/:id", requireAuth, async (req, res) => {
    try {
      const report = await storage.updateReport(req.params.id, req.body);
      if (!report) {
        return res.status(404).json({ error: "Report not found" });
      }
      res.json(report);
    } catch (error) {
      console.error("Error updating report:", error);
      res.status(500).json({ error: "Failed to update report" });
    }
  });
  app2.delete("/api/admin/reports/:id", requireAuth, async (req, res) => {
    try {
      const success = await storage.deleteReport(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Report not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting report:", error);
      res.status(500).json({ error: "Failed to delete report" });
    }
  });
  app2.get("/api/admin/settings", requireAuth, async (req, res) => {
    try {
      const settings2 = await storage.getAllSettings();
      res.json(settings2);
    } catch (error) {
      console.error("Error fetching settings:", error);
      res.status(500).json({ error: "Failed to fetch settings" });
    }
  });
  app2.post("/api/admin/settings", requireAuth, async (req, res) => {
    try {
      const setting = await storage.createSetting(req.body);
      res.json(setting);
    } catch (error) {
      console.error("Error creating setting:", error);
      res.status(500).json({ error: "Failed to create setting" });
    }
  });
  app2.put("/api/admin/settings/:id", requireAuth, async (req, res) => {
    try {
      const setting = await storage.updateSetting(req.params.id, req.body);
      if (!setting) {
        return res.status(404).json({ error: "Setting not found" });
      }
      res.json(setting);
    } catch (error) {
      console.error("Error updating setting:", error);
      res.status(500).json({ error: "Failed to update setting" });
    }
  });
  app2.delete("/api/admin/settings/:id", requireAuth, async (req, res) => {
    try {
      const success = await storage.deleteSetting(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Setting not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting setting:", error);
      res.status(500).json({ error: "Failed to delete setting" });
    }
  });
  app2.get("/api/legislation", async (req, res) => {
    try {
      const legislation2 = await storage.getAllLegislation();
      res.json(legislation2);
    } catch (error) {
      console.error("Error fetching legislation:", error);
      res.status(500).json({ error: "Failed to fetch legislation" });
    }
  });
  app2.get("/api/legislation/:id", async (req, res) => {
    try {
      const legislation2 = await storage.getLegislation(req.params.id);
      if (!legislation2) {
        return res.status(404).json({ error: "Legislation not found" });
      }
      res.json(legislation2);
    } catch (error) {
      console.error("Error fetching legislation:", error);
      res.status(500).json({ error: "Failed to fetch legislation" });
    }
  });
  app2.get("/api/publications", async (req, res) => {
    try {
      const publications2 = await storage.getAllPublications();
      res.json(publications2);
    } catch (error) {
      console.error("Error fetching publications:", error);
      res.status(500).json({ error: "Failed to fetch publications" });
    }
  });
  app2.get("/api/events", async (req, res) => {
    try {
      const events2 = await storage.getAllEvents();
      res.json(events2);
    } catch (error) {
      console.error("Error fetching events:", error);
      res.status(500).json({ error: "Failed to fetch events" });
    }
  });
  app2.post("/api/legislation", async (req, res) => {
    try {
      const data = req.body;
      const newLegislation = await storage.createLegislation(data);
      res.json(newLegislation);
    } catch (error) {
      console.error("Error creating legislation:", error);
      res.status(500).json({ error: "Failed to create legislation" });
    }
  });
  app2.put("/api/legislation/:id", async (req, res) => {
    try {
      const id = req.params.id;
      const data = req.body;
      const updatedLegislation = await storage.updateLegislation(id, data);
      res.json(updatedLegislation);
    } catch (error) {
      console.error("Error updating legislation:", error);
      res.status(500).json({ error: "Failed to update legislation" });
    }
  });
  app2.delete("/api/legislation/:id", async (req, res) => {
    try {
      const id = req.params.id;
      const success = await storage.deleteLegislation(id);
      res.json({ success });
    } catch (error) {
      console.error("Error deleting legislation:", error);
      res.status(500).json({ error: "Failed to delete legislation" });
    }
  });
  app2.get("/api/about", async (req, res) => {
    try {
      const about = await storage.getAboutContent();
      res.json(about);
    } catch (error) {
      console.error("Error fetching about data:", error);
      res.status(500).json({ error: "Failed to fetch about data" });
    }
  });
  app2.put("/api/about", async (req, res) => {
    try {
      const data = req.body;
      const aboutContent2 = await storage.getAboutContent();
      if (aboutContent2.length > 0) {
        const updatedAbout = await storage.updateAboutContent(aboutContent2[0].id, data);
        res.json(updatedAbout);
      } else {
        const newAbout = await storage.createAboutContent(data);
        res.json(newAbout);
      }
    } catch (error) {
      console.error("Error updating about data:", error);
      res.status(500).json({ error: "Failed to update about data" });
    }
  });
  app2.get("/api/gallery", async (req, res) => {
    try {
      const gallery2 = await storage.getAllGallery();
      res.json(gallery2);
    } catch (error) {
      console.error("Error fetching gallery:", error);
      res.status(500).json({ error: "Failed to fetch gallery" });
    }
  });
  app2.post("/api/seed-slideshow", async (req, res) => {
    try {
      console.log("\u{1F331} Iniciando seed do slideshow...");
      const defaultSlides = [
        {
          title: "Profissionais do Espectro R\xE1dio Eletr\xF3nico",
          subtitle: "Unindo especialistas em telecomunica\xE7\xF5es de Angola",
          description: "ANPERE representa e apoia os profissionais que trabalham com o espectro r\xE1dio eletr\xF3nico, promovendo excel\xEAncia t\xE9cnica e desenvolvimento profissional.",
          imageUrl: "/attached_assets/generated_images/Angolan_telecommunications_professionals_working_640a21c0.png",
          order: 0,
          isActive: true
        },
        {
          title: "Tecnologia e Inova\xE7\xE3o",
          subtitle: "Avan\xE7ando nas telecomunica\xE7\xF5es angolanas",
          description: "Contribu\xEDmos para o desenvolvimento das telecomunica\xE7\xF5es em Angola atrav\xE9s da forma\xE7\xE3o cont\xEDnua e partilha de conhecimento t\xE9cnico.",
          imageUrl: "/attached_assets/generated_images/Telecommunications_tower_in_Luanda_Angola_da464df4.png",
          order: 1,
          isActive: true
        },
        {
          title: "Membros da ANPERE",
          subtitle: "Unidos pela profiss\xE3o",
          description: "Membros da ANPERE reunidos, representando a for\xE7a e uni\xE3o dos profissionais do espectro r\xE1dio eletr\xF3nico em Angola.",
          imageUrl: "/attached_assets/IMG-20240214-WA0082_1759411408988.jpg",
          order: 2,
          isActive: true
        },
        {
          title: "Assembleia de Constitui\xE7\xE3o da ANPERE",
          subtitle: "Unidade e determina\xE7\xE3o dos profissionais",
          description: "Momento hist\xF3rico da funda\xE7\xE3o da nossa associa\xE7\xE3o, onde profissionais de telecomunica\xE7\xF5es se uniram para criar uma organiza\xE7\xE3o forte e representativa do setor em Angola.",
          imageUrl: "/attached_assets/Gemini_Generated_Image_y9zwpuy9zwpuy9zw_1758927089316.png",
          order: 3,
          isActive: true
        }
      ];
      const existingSlides = await storage.getAllSlideshow();
      const existingUrls = new Set(existingSlides.map((slide) => slide.imageUrl).filter(Boolean));
      let addedCount = 0;
      let skippedCount = 0;
      for (const slide of defaultSlides) {
        try {
          if (existingUrls.has(slide.imageUrl)) {
            console.log(`\u23ED\uFE0F  Slide j\xE1 existe, pulando: ${slide.title}`);
            skippedCount++;
            continue;
          }
          const insertedSlide = await storage.createSlideshow(slide);
          if (insertedSlide) {
            addedCount++;
            existingUrls.add(slide.imageUrl);
            console.log(`\u2705 Slide criado: ${slide.title}`);
          }
        } catch (error) {
          console.error(`\u274C Erro ao criar slide: ${slide.title}`, error.message);
        }
      }
      console.log(`\u{1F389} Seed do slideshow conclu\xEDdo! Criados: ${addedCount} slides, pulados: ${skippedCount} duplicados`);
      res.json({
        success: true,
        message: `Slideshow seed conclu\xEDdo! ${addedCount} novos slides adicionados, ${skippedCount} j\xE1 existiam.`,
        count: addedCount,
        skipped: skippedCount,
        total: addedCount + skippedCount
      });
    } catch (error) {
      console.error("\u274C Erro no seed do slideshow:", error);
      res.status(500).json({
        success: false,
        message: "Erro ao criar slides do slideshow",
        error: error.message
      });
    }
  });
  app2.post("/api/seed-activity-plan-2025", async (req, res) => {
    try {
      console.log("\u{1F331} Iniciando seed do plano de atividades 2025...");
      const existingPlans = await storage.getAllActivityPlans();
      const plan2025 = existingPlans.find((p) => p.year === "2025");
      let planId;
      if (plan2025) {
        planId = plan2025.id;
        console.log(`\u23ED\uFE0F  Plano 2025 j\xE1 existe, usando: ${planId}`);
        const existingItems = await storage.getActivityPlanItems(planId);
        for (const item of existingItems) {
          await storage.deleteActivityPlanItem(item.id);
        }
      } else {
        const newPlan = await storage.createActivityPlan({
          year: "2025",
          title: "Plano de Atividades",
          description: "Plano de atividades da ANPERE para o ano de 2025",
          isActive: true
        });
        planId = newPlan.id;
        console.log(`\u2705 Plano 2025 criado: ${planId}`);
      }
      const activities = [
        // Item 1
        { number: 1, activity: "Reuni\xF5es de dire\xE7\xE3o [5]", date: "Janeiro a Dezembro", time: "A indicar", location: "Sede", participants: "Membros", order: 0 },
        // Item 2
        { number: 2, activity: "Difus\xE3o de mensagens em datas de efem\xE9rides [5]", date: "Janeiro a Dezembro", time: "A indicar", location: "Sede", participants: "[5]", order: 1 },
        { number: 2, activity: "Janeiro de troca", date: "Janeiro", time: "A indicar", location: "Sede Social", participants: "[5]", order: 2, parentNumber: 2 },
        // Item 3
        { number: 3, activity: "FOCABA", date: "FOCABA", time: "A indicar", location: "Desdembren", participants: "Dire\xE7\xE3o [5]", order: 3 },
        // Item 4
        { number: 4, activity: "Reuni\xF5es de doadores e experi\xEAncia FOCABA", date: "FOCABA", time: "A indicar", location: "", participants: "Membros da dire\xE7\xE3o", order: 4 },
        { number: 4, activity: "Visita aos doadores e entrega de cesta b\xE1sica", date: "Mensalmente", time: "A indicar", location: "FOCABA", participants: "Membros [5]", order: 5, parentNumber: 4 },
        { number: 4, activity: "Trimestralmente", date: "Trimestralmente", time: "A indicar", location: "A indicar", participants: "Membros [5]", order: 6, parentNumber: 4 },
        // Item 5
        { number: 5, activity: "Exposi\xE7\xE3o da hist\xF3ria do R (Lda, Hbo, Mo, Mox, Nam Mal, Hu\xEDla)", date: "Trimestralmente", time: "A indicar", location: "Membros da", participants: "Fam\xEDlia R, etc [5]", order: 7 },
        { number: 5, activity: "Trimestralmente", date: "Trimestralmente", time: "A indicar", location: "A indicar", participants: "Membros [9]", order: 8, parentNumber: 5 },
        { number: 5, activity: "Acto constitutivo, etc", date: "Trimestralmente", time: "A indicar", location: "Sede", participants: "Membros [5]", order: 9, parentNumber: 5 },
        // Item 6
        { number: 6, activity: "Sess\xE3o cinema com a Fotografia, Viagem envolvente t\xE9cnica", date: "Trimestralmente", time: "A indicar", location: "Barra do Dande, Barra de Quanza, Marco Hist\xF3rico do Kifangondo", participants: "", order: 10 },
        // Item 7
        { number: 7, activity: "Sess\xF5es Tur\xEDsticas", date: "Trimestralmente", time: "A indicar", location: "Sede", participants: "Membros [9]", order: 11 },
        { number: 7, activity: "Porto de Luanda x", date: "Trimestralmente", time: "7:00 AM", location: "A indicar", participants: "Membros [9]", order: 12, parentNumber: 7 },
        // Item 8
        { number: 8, activity: "Caminhadas pedestres", date: "Mensalmente", time: "7:00 AM", location: "", participants: "Membros - Fam\xEDlia R", order: 13 },
        // Item 9
        { number: 9, activity: "Jogos de futsal", date: "", time: "A indicar", location: "Sede", participants: "[5]", order: 14 },
        // Item 10
        { number: 10, activity: "Jogos de xadrez", date: "Trimestralmente", time: "A indicar", location: "Sede", participants: "Membros da Fam\xEDlia R", order: 15 }
      ];
      let addedCount = 0;
      const parentItemsMap = /* @__PURE__ */ new Map();
      for (const activity of activities) {
        try {
          const itemData = {
            planId,
            number: activity.number,
            activity: activity.activity,
            date: activity.date || null,
            time: activity.time || null,
            location: activity.location || null,
            participants: activity.participants || null,
            order: activity.order
          };
          if (activity.parentNumber) {
            const parentId = parentItemsMap.get(activity.parentNumber);
            if (parentId) {
              itemData.parentId = parentId;
            }
          }
          const insertedItem = await storage.createActivityPlanItem(itemData);
          addedCount++;
          if (!activity.parentNumber) {
            parentItemsMap.set(activity.number, insertedItem.id);
          }
          console.log(`\u2705 Item criado: ${activity.number}. ${activity.activity}`);
        } catch (error) {
          console.error(`\u274C Erro ao criar item: ${activity.activity}`, error.message);
        }
      }
      console.log(`\u{1F389} Seed do plano de atividades 2025 conclu\xEDdo! Criados: ${addedCount} itens`);
      res.json({
        success: true,
        message: `Plano de atividades 2025 criado com sucesso! ${addedCount} atividades adicionadas.`,
        count: addedCount,
        planId
      });
    } catch (error) {
      console.error("\u274C Erro no seed do plano de atividades 2025:", error);
      res.status(500).json({
        success: false,
        message: "Erro ao criar plano de atividades 2025",
        error: error.message
      });
    }
  });
  app2.post("/api/seed-estatutos", async (req, res) => {
    try {
      console.log("\u{1F331} Iniciando seed dos estatutos...");
      const uploadsDir = path.join(process.cwd(), "uploads");
      let fileName = "ESTATUTOS REVISTOS JUNHO DE 2025_VERS\xC3O SEM RODAP\xC9.pdf";
      let filePath = path.join(uploadsDir, fileName);
      if (!fs.existsSync(filePath) && fs.existsSync(uploadsDir)) {
        const files = fs.readdirSync(uploadsDir);
        const estatutosFile = files.find((f) => f.toLowerCase().includes("estatuto"));
        if (estatutosFile) {
          fileName = estatutosFile;
          filePath = path.join(uploadsDir, estatutosFile);
        }
      }
      if (!fs.existsSync(filePath)) {
        console.warn(`\u26A0\uFE0F Arquivo de estatutos n\xE3o encontrado: ${filePath}`);
      }
      const estatutosContent = `
<h1 class="text-4xl font-bold mb-6">ESTATUTOS DA ANPERE</h1>

<h2 class="text-3xl font-bold mb-4">ASSOCIA\xC7\xC3O NACIONAL DOS PROFISSIONAIS DO ESPECTRO R\xC1DIO ELECTR\xD3NICO</h2>

<p class="text-lg font-semibold mb-8">Vers\xE3o revista em Junho de 2025</p>

<hr class="my-8 border-t-2 border-border" />

<h2 class="text-3xl font-bold mt-10 mb-4 text-primary">CAP\xCDTULO I</h2>
<h3 class="text-xl font-semibold mb-6">Da Denomina\xE7\xE3o, Sede, Natureza, Dura\xE7\xE3o e Fins</h3>

<h4 class="text-lg font-bold mt-6 mb-3">Artigo 1.\xBA</h4>
<p class="italic mb-3 text-muted-foreground">(Denomina\xE7\xE3o e sede)</p>
<p class="mb-4 leading-relaxed">A Associa\xE7\xE3o Nacional dos Profissionais do Espectro R\xE1dio Electr\xF3nico, abreviadamente designada por ANPERE, \xE9 uma pessoa colectiva de direito privado, sem fins lucrativos, dotada de personalidade jur\xEDdica e de autonomia administrativa e financeira, com sede na cidade de Luanda, Rep\xFAblica de Angola.</p>

<h4 class="text-lg font-bold mt-6 mb-3">Artigo 2.\xBA</h4>
<p class="italic mb-3 text-muted-foreground">(Natureza)</p>
<p class="mb-4 leading-relaxed">A ANPERE \xE9 uma associa\xE7\xE3o de car\xE1cter profissional, cultural, recreativo e social, que visa promover e defender os interesses dos seus associados.</p>

<h4 class="text-lg font-bold mt-6 mb-3">Artigo 3.\xBA</h4>
<p class="italic mb-3 text-muted-foreground">(Dura\xE7\xE3o)</p>
<p class="mb-4 leading-relaxed">A ANPERE tem dura\xE7\xE3o ilimitada.</p>

<h4 class="text-lg font-bold mt-6 mb-3">Artigo 4.\xBA</h4>
<p class="italic mb-3 text-muted-foreground">(Fins)</p>
<p class="mb-2 leading-relaxed">Sem preju\xEDzo do disposto na lei, a ANPERE tem por fim:</p>
<ul class="list-disc list-inside mb-4 space-y-2 ml-6">
  <li class="mb-2">Representar e defender os interesses profissionais, sociais e econ\xF3micos dos seus associados;</li>
  <li class="mb-2">Promover a forma\xE7\xE3o e o aperfei\xE7oamento profissional dos associados;</li>
  <li class="mb-2">Contribuir para o desenvolvimento t\xE9cnico e cient\xEDfico do sector das telecomunica\xE7\xF5es;</li>
  <li class="mb-2">Prestar assist\xEAncia social, jur\xEDdica e t\xE9cnica aos associados;</li>
  <li class="mb-2">Promover actividades culturais, recreativas e desportivas;</li>
  <li class="mb-2">Estabelecer rela\xE7\xF5es de coopera\xE7\xE3o com outras associa\xE7\xF5es e organiza\xE7\xF5es nacionais e internacionais;</li>
  <li class="mb-2">Participar em iniciativas de interesse p\xFAblico relacionadas com o sector.</li>
</ul>

<h2 class="text-3xl font-bold mt-10 mb-4 text-primary">CAP\xCDTULO II</h2>
<h3 class="text-xl font-semibold mb-6">Dos Associados</h3>

<h4 class="text-lg font-bold mt-6 mb-3">Artigo 5.\xBA</h4>
<p class="italic mb-3 text-muted-foreground">(Condi\xE7\xF5es de admiss\xE3o)</p>
<p class="mb-4 leading-relaxed">Podem ser associados da ANPERE todas as pessoas que exer\xE7am ou tenham exercido profiss\xF5es relacionadas com o espectro r\xE1dio electr\xF3nico, que aceitem os estatutos e cumpram as condi\xE7\xF5es fixadas na lei e no presente documento.</p>

<h4 class="text-lg font-bold mt-6 mb-3">Artigo 6.\xBA</h4>
<p class="italic mb-3 text-muted-foreground">(Categorias de associados)</p>
<p class="mb-2 leading-relaxed">Os associados dividem-se em:</p>
<ul class="list-disc list-inside mb-4 space-y-2 ml-6">
  <li class="mb-2">Efectivos;</li>
  <li class="mb-2">Honor\xE1rios;</li>
  <li class="mb-2">Benem\xE9ritos.</li>
</ul>

<h2 class="text-3xl font-bold mt-10 mb-4 text-primary">CAP\xCDTULO III</h2>
<h3 class="text-xl font-semibold mb-6">Dos \xD3rg\xE3os Sociais</h3>

<h4 class="text-lg font-bold mt-6 mb-3">Artigo 7.\xBA</h4>
<p class="italic mb-3 text-muted-foreground">(\xD3rg\xE3os da Associa\xE7\xE3o)</p>
<p class="mb-2 leading-relaxed">S\xE3o \xF3rg\xE3os da ANPERE:</p>
<ul class="list-disc list-inside mb-4 space-y-2 ml-6">
  <li class="mb-2">Assembleia Geral;</li>
  <li class="mb-2">Direc\xE7\xE3o;</li>
  <li class="mb-2">Conselho Fiscal.</li>
</ul>

<h2 class="text-3xl font-bold mt-10 mb-4 text-primary">CAP\xCDTULO IV</h2>
<h3 class="text-xl font-semibold mb-6">Das Receitas</h3>

<h4 class="text-lg font-bold mt-6 mb-3">Artigo 8.\xBA</h4>
<p class="italic mb-3 text-muted-foreground">(Receitas da Associa\xE7\xE3o)</p>
<p class="mb-2 leading-relaxed">As receitas da ANPERE prov\xEAm de:</p>
<ul class="list-disc list-inside mb-4 space-y-2 ml-6">
  <li class="mb-2">Joias e quotas dos associados;</li>
  <li class="mb-2">Donativos e subs\xEDdios;</li>
  <li class="mb-2">Rendimentos de bens pr\xF3prios;</li>
  <li class="mb-2">Receitas de actividades organizadas pela Associa\xE7\xE3o;</li>
  <li class="mb-2">Outras receitas legalmente admitidas.</li>
</ul>

<div class="mt-8 p-4 bg-muted rounded-lg">
  <p class="text-sm italic"><strong>Nota:</strong> Este \xE9 um resumo estruturado dos estatutos principais. Para o conte\xFAdo completo, detalhado e oficial, incluindo todos os artigos e disposi\xE7\xF5es, consulte o PDF oficial dispon\xEDvel para download abaixo.</p>
</div>
      `.trim();
      const existingLegislations = await storage.getAllLegislation();
      const estatutos2025 = existingLegislations.find(
        (l) => l.category === "Estatuto" && l.year === "2025"
      );
      let estatutoId;
      if (estatutos2025) {
        estatutoId = estatutos2025.id;
        console.log(`\u23ED\uFE0F  Estatutos 2025 j\xE1 existem, atualizando...`);
        const updateData = {
          content: estatutosContent
        };
        if (fs.existsSync(filePath || "")) {
          updateData.fileUrl = `/uploads/${encodeURIComponent(fileName)}`;
        }
        await storage.updateLegislation(estatutoId, updateData);
      } else {
        const newEstatuto = await storage.createLegislation({
          title: "Estatutos da ANPERE",
          description: "Estatutos revistos da Associa\xE7\xE3o Nacional dos Profissionais do Espectro R\xE1dio Electr\xF3nico - Vers\xE3o Junho de 2025",
          category: "Estatuto",
          year: "2025",
          icon: "BookOpen",
          content: estatutosContent,
          fileUrl: fs.existsSync(filePath) ? `/uploads/${encodeURIComponent(fileName)}` : void 0
        });
        estatutoId = newEstatuto.id;
        console.log(`\u2705 Estatutos 2025 criados: ${estatutoId}`);
      }
      res.json({
        success: true,
        message: "Estatutos carregados com sucesso!",
        id: estatutoId
      });
    } catch (error) {
      console.error("\u274C Erro no seed dos estatutos:", error);
      res.status(500).json({
        success: false,
        message: "Erro ao carregar estatutos",
        error: error.message
      });
    }
  });
  app2.post("/api/seed-visitas-ajudas", async (req, res) => {
    try {
      console.log("\u{1F331} Iniciando seed das imagens de visitas de ajudas...");
      const visitasAjudas = [
        {
          title: "Visita Comunit\xE1ria - Distribui\xE7\xE3o de Ajudas",
          description: "Visita comunit\xE1ria da ANPERE para distribui\xE7\xE3o de ajudas a idosos e fam\xEDlias necessitadas. Momento de solidariedade e apoio social.",
          type: "image",
          date: "Fevereiro 2024",
          category: "Ajuda Social",
          mediaUrl: "/attached_assets/IMG-20240214-WA0082_1759411408988.jpg",
          thumbnail: "/attached_assets/IMG-20240214-WA0082_1759411408988.jpg"
        },
        {
          title: "Entrega de Doa\xE7\xF5es - Comunidade",
          description: "Equipa da ANPERE entregando doa\xE7\xF5es e suprimentos essenciais durante visita comunit\xE1ria. Demonstra\xE7\xE3o do compromisso da associa\xE7\xE3o com a\xE7\xF5es sociais.",
          type: "image",
          date: "Janeiro 2024",
          category: "Ajuda Social",
          mediaUrl: "/attached_assets/Gemini_Generated_Image_y9zwpuy9zwpuy9zw_1758927089316.png",
          thumbnail: "/attached_assets/Gemini_Generated_Image_y9zwpuy9zwpuy9zw_1758927089316.png"
        },
        {
          title: "Visita a Institui\xE7\xE3o de Caridade",
          description: "Membros da ANPERE visitando institui\xE7\xE3o de caridade para prestar apoio e entregar donativos. A\xE7\xE3o solid\xE1ria promovendo bem-estar social.",
          type: "image",
          date: "Mar\xE7o 2024",
          category: "Ajuda Social",
          mediaUrl: "/attached_assets/Gemini_Generated_Image_y9zwpuy9zwpuy9zw_1758926715022.png",
          thumbnail: "/attached_assets/Gemini_Generated_Image_y9zwpuy9zwpuy9zw_1758926715022.png"
        },
        {
          title: "Distribui\xE7\xE3o de Alimentos",
          description: "Distribui\xE7\xE3o de alimentos e produtos essenciais para fam\xEDlias carentes durante a\xE7\xE3o comunit\xE1ria organizada pela ANPERE.",
          type: "image",
          date: "Abril 2024",
          category: "Ajuda Social",
          mediaUrl: "/attached_assets/Gemini_Generated_Image_y9zwpuy9zwpuy9zw_1758924960266.png",
          thumbnail: "/attached_assets/Gemini_Generated_Image_y9zwpuy9zwpuy9zw_1758924960266.png"
        },
        {
          title: "Visita ao Lar de Idosos",
          description: "Visita solid\xE1ria da ANPERE a lar de idosos, proporcionando momentos de alegria e entregando donativos. Compromisso com causas sociais.",
          type: "image",
          date: "Maio 2024",
          category: "Ajuda Social",
          mediaUrl: "/attached_assets/Gemini_Generated_Image_vlpezzvlpezzvlpe.png",
          thumbnail: "/attached_assets/Gemini_Generated_Image_vlpezzvlpezzvlpe.png"
        },
        {
          title: "A\xE7\xE3o Social - Comunidade",
          description: "A\xE7\xE3o social promovida pela ANPERE na comunidade, com distribui\xE7\xE3o de bens essenciais e momentos de conv\xEDvio. Solidariedade em a\xE7\xE3o.",
          type: "image",
          date: "Junho 2024",
          category: "Ajuda Social",
          mediaUrl: "/attached_assets/Gemini_Generated_Image_vlpezzvlpezzvlpe_1758913669762.png",
          thumbnail: "/attached_assets/Gemini_Generated_Image_vlpezzvlpezzvlpe_1758913669762.png"
        },
        {
          title: "Doa\xE7\xF5es \xE0 Comunidade",
          description: "Entrega de doa\xE7\xF5es e produtos de primeira necessidade durante a\xE7\xE3o comunit\xE1ria. ANPERE promovendo solidariedade e apoio social.",
          type: "image",
          date: "Julho 2024",
          category: "Ajuda Social",
          mediaUrl: "/attached_assets/ChatGPT Image 26 de set. de 2025, 20_37_30.png",
          thumbnail: "/attached_assets/ChatGPT Image 26 de set. de 2025, 20_37_30.png"
        },
        {
          title: "Visita Solid\xE1ria - Fam\xEDlias",
          description: "Visita solid\xE1ria a fam\xEDlias necessitadas, entregando ajuda e demonstrando o compromisso social da ANPERE com a comunidade.",
          type: "image",
          date: "Agosto 2024",
          category: "Ajuda Social",
          mediaUrl: "/attached_assets/ChatGPT Image 26_09_2025, 20_24_00.png",
          thumbnail: "/attached_assets/ChatGPT Image 26_09_2025, 20_24_00.png"
        },
        {
          title: "A\xE7\xE3o de Solidariedade",
          description: "A\xE7\xE3o de solidariedade da ANPERE, oferecendo apoio material e emocional durante visita comunit\xE1ria. Responsabilidade social em pr\xE1tica.",
          type: "image",
          date: "Setembro 2024",
          category: "Ajuda Social",
          mediaUrl: "/attached_assets/ChatGPT Image 26_09_2025, 20_19_29.png",
          thumbnail: "/attached_assets/ChatGPT Image 26_09_2025, 20_19_29.png"
        },
        {
          title: "Visita Comunit\xE1ria - Apoio a Idosos",
          description: "Visita comunit\xE1ria da ANPERE oferecendo apoio e assist\xEAncia a idosos. Momento de carinho e cuidado com a comunidade.",
          type: "image",
          date: "Outubro 2024",
          category: "Ajuda Social",
          mediaUrl: "/attached_assets/Captura de ecra\u0303 2025-09-26 133220_1758890221295.png",
          thumbnail: "/attached_assets/Captura de ecra\u0303 2025-09-26 133220_1758890221295.png"
        },
        {
          title: "Distribui\xE7\xE3o de Suprimentos - Comunidade",
          description: "Distribui\xE7\xE3o de suprimentos essenciais durante a\xE7\xE3o comunit\xE1ria. ANPERE demonstrando compromisso com o bem-estar social.",
          type: "image",
          date: "Novembro 2024",
          category: "Ajuda Social",
          mediaUrl: "/attached_assets/Captura de ecra\u0303 2025-09-26 133249_1758890221294.png",
          thumbnail: "/attached_assets/Captura de ecra\u0303 2025-09-26 133249_1758890221294.png"
        },
        {
          title: "Visita de Apoio - Fam\xEDlias Carentes",
          description: "Visita de apoio da ANPERE a fam\xEDlias carentes, distribuindo ajuda e proporcionando momentos de alegria e esperan\xE7a.",
          type: "image",
          date: "Dezembro 2024",
          category: "Ajuda Social",
          mediaUrl: "/attached_assets/Captura de ecra\u0303 2025-09-26 134052_1758890569794.png",
          thumbnail: "/attached_assets/Captura de ecra\u0303 2025-09-26 134052_1758890569794.png"
        },
        {
          title: "Visita Comunit\xE1ria - Entrega de Cadeira de Rodas",
          description: "Membros da ANPERE entregando cadeira de rodas nova durante visita comunit\xE1ria. Apoio essencial para mobilidade e qualidade de vida.",
          type: "image",
          date: "Janeiro 2025",
          category: "Ajuda Social",
          mediaUrl: "/attached_assets/Captura de Tela 2025-09-25 \xE0s 20.55.51_1758830420053.png",
          thumbnail: "/attached_assets/Captura de Tela 2025-09-25 \xE0s 20.55.51_1758830420053.png"
        },
        {
          title: "A\xE7\xE3o Solid\xE1ria - Distribui\xE7\xE3o de Bens",
          description: "A\xE7\xE3o solid\xE1ria da ANPERE com distribui\xE7\xE3o de bens essenciais e produtos de higiene. Compromisso com o bem-estar da comunidade.",
          type: "image",
          date: "Fevereiro 2025",
          category: "Ajuda Social",
          mediaUrl: "/attached_assets/screenshot-1758374140759.png",
          thumbnail: "/attached_assets/screenshot-1758374140759.png"
        },
        {
          title: "Visita Comunit\xE1ria - Reuni\xE3o de Apoio",
          description: "Reuni\xE3o comunit\xE1ria da ANPERE para planejamento de a\xE7\xF5es de apoio e distribui\xE7\xE3o de ajudas. Engajamento social e solidariedade.",
          type: "image",
          date: "Mar\xE7o 2025",
          category: "Ajuda Social",
          mediaUrl: "/attached_assets/Captura de ecra\u0303 2025-09-26 133220_1758890221295.png",
          thumbnail: "/attached_assets/Captura de ecra\u0303 2025-09-26 133220_1758890221295.png"
        },
        {
          title: "Entrega de Suprimentos - Fam\xEDlias",
          description: "Entrega de suprimentos e produtos essenciais a fam\xEDlias durante visita comunit\xE1ria. ANPERE promovendo bem-estar e apoio social.",
          type: "image",
          date: "Abril 2025",
          category: "Ajuda Social",
          mediaUrl: "/attached_assets/Captura de ecra\u0303 2025-09-26 133249_1758890221294.png",
          thumbnail: "/attached_assets/Captura de ecra\u0303 2025-09-26 133249_1758890221294.png"
        },
        {
          title: "Visita de Solidariedade - Comunidade",
          description: "Visita de solidariedade da ANPERE \xE0 comunidade, oferecendo apoio e distribuindo donativos. Compromisso com a\xE7\xF5es sociais.",
          type: "image",
          date: "Maio 2025",
          category: "Ajuda Social",
          mediaUrl: "/attached_assets/Captura de ecra\u0303 2025-09-26 134052_1758890569794.png",
          thumbnail: "/attached_assets/Captura de ecra\u0303 2025-09-26 134052_1758890569794.png"
        }
      ];
      const existingItems = await storage.getAllGallery();
      const existingUrls = new Set(existingItems.map((item) => item.mediaUrl).filter(Boolean));
      let addedCount = 0;
      let skippedCount = 0;
      for (const visita of visitasAjudas) {
        try {
          if (visita.mediaUrl && existingUrls.has(visita.mediaUrl)) {
            console.log(`\u23ED\uFE0F  Item j\xE1 existe, pulando: ${visita.title}`);
            skippedCount++;
            continue;
          }
          const insertedItem = await storage.createGalleryItem(visita);
          if (insertedItem) {
            addedCount++;
            existingUrls.add(visita.mediaUrl || "");
            console.log(`\u2705 Item de galeria criado: ${visita.title}`);
          }
        } catch (error) {
          console.error(`\u274C Erro ao criar item: ${visita.title}`, error.message);
        }
      }
      console.log(`\u{1F389} Seed de visitas de ajudas conclu\xEDdo! Criados: ${addedCount} itens, pulados: ${skippedCount} duplicados`);
      res.json({
        success: true,
        message: `Imagens de visitas de ajudas adicionadas com sucesso! ${addedCount} novas imagens adicionadas, ${skippedCount} j\xE1 existiam.`,
        count: addedCount,
        skipped: skippedCount,
        total: addedCount + skippedCount
      });
    } catch (error) {
      console.error("\u274C Erro no seed de visitas:", error);
      res.status(500).json({
        success: false,
        message: "Erro ao adicionar imagens de visitas de ajudas",
        error: error.message
      });
    }
  });
  app2.post("/api/seed-sample-data", async (req, res) => {
    try {
      console.log("\u{1F331} Iniciando seed dos dados de exemplo...");
      const events2 = [
        {
          title: "Confer\xEAncia Nacional de Telecomunica\xE7\xF5es 2024",
          description: "Evento anual que re\xFAne os principais profissionais do setor de telecomunica\xE7\xF5es para debater tend\xEAncias, inova\xE7\xF5es tecnol\xF3gicas e o futuro das comunica\xE7\xF5es em Angola. Palestrantes nacionais e internacionais apresentar\xE3o cases de sucesso e novas tecnologias.",
          date: "15 de Junho, 2024",
          time: "09:00 - 17:00",
          location: "Hotel Presidente, Luanda",
          type: "Confer\xEAncia",
          capacity: "200",
          registrationDeadline: "10 de Junho, 2024",
          cost: "15.000 AOA",
          imageUrl: "/lovable-uploads/0194c04c-ec72-4ff9-9fd0-e1db7c6f4ef8.png"
        },
        {
          title: "Workshop: Tecnologias 5G e o Futuro das Telecomunica\xE7\xF5es",
          description: "Workshop pr\xE1tico sobre as novas tecnologias 5G e seu impacto no futuro das telecomunica\xE7\xF5es em Angola. Sess\xF5es hands-on com equipamentos reais e demonstra\xE7\xF5es pr\xE1ticas das principais funcionalidades e aplica\xE7\xF5es do 5G.",
          date: "22 de Maio, 2024",
          time: "14:00 - 18:00",
          location: "Centro de Conven\xE7\xF5es de Talatona",
          type: "Workshop",
          capacity: "50",
          registrationDeadline: "18 de Maio, 2024",
          cost: "Gratuito para membros",
          imageUrl: "/lovable-uploads/4bfb5b81-7f66-44a6-8a90-6b7a85c12c14.png"
        },
        {
          title: "Semin\xE1rio de Seguran\xE7a Cibern\xE9tica em Telecomunica\xE7\xF5es",
          description: "Semin\xE1rio especializado sobre seguran\xE7a cibern\xE9tica no setor de telecomunica\xE7\xF5es. Abordagem de amea\xE7as atuais, melhores pr\xE1ticas de prote\xE7\xE3o, conformidade regulat\xF3ria e casos pr\xE1ticos de implementa\xE7\xE3o de seguran\xE7a.",
          date: "8 de Julho, 2024",
          time: "09:30 - 16:30",
          location: "Universidade Cat\xF3lica de Angola, Luanda",
          type: "Semin\xE1rio",
          capacity: "80",
          registrationDeadline: "3 de Julho, 2024",
          cost: "8.000 AOA",
          imageUrl: "/lovable-uploads/f47ac10b-58cc-4372-a567-0e02b2c3d479.png"
        },
        {
          title: "Curso de Certifica\xE7\xE3o Profissional ANPERE",
          description: "Curso intensivo de certifica\xE7\xE3o profissional para t\xE9cnicos do setor de telecomunica\xE7\xF5es. Programa abrangente cobrindo aspectos t\xE9cnicos, regulamentares e \xE9ticos da profiss\xE3o, com certifica\xE7\xE3o reconhecida nacionalmente.",
          date: "12 de Agosto, 2024",
          time: "08:00 - 17:00",
          location: "Instituto Superior Polit\xE9cnico do Kwanza Sul",
          type: "Curso",
          capacity: "30",
          registrationDeadline: "5 de Agosto, 2024",
          cost: "25.000 AOA",
          imageUrl: "/lovable-uploads/0194c04c-ec72-4ff9-9fd0-e1db7c6f4ef8.png"
        },
        {
          title: "Encontro Regional de Profissionais do Interior",
          description: "Encontro regional destinado aos profissionais do interior do pa\xEDs para discuss\xE3o de desafios espec\xEDficos das telecomunica\xE7\xF5es em zonas rurais. Networking, partilha de experi\xEAncias e estrat\xE9gias de desenvolvimento regional.",
          date: "18 de Setembro, 2024",
          time: "09:00 - 15:00",
          location: "Hotel Kandengue, Huambo",
          type: "Encontro",
          capacity: "120",
          registrationDeadline: "12 de Setembro, 2024",
          cost: "5.000 AOA",
          imageUrl: "/lovable-uploads/4bfb5b81-7f66-44a6-8a90-6b7a85c12c14.png"
        }
      ];
      const publications2 = [
        {
          title: "Plano de Actividades ANPERE 2024",
          description: "Documento oficial que apresenta o plano estrat\xE9gico e actividades previstas para o ano de 2024. Inclui objectivos, metas, cronograma de eventos, projectos de desenvolvimento profissional e iniciativas de fortalecimento do setor.",
          category: "Plano Estrat\xE9gico",
          date: "Janeiro 2024",
          fileUrl: "/api/placeholder/document/plano-actividades-2024.pdf",
          downloadUrl: null
        },
        {
          title: "Relat\xF3rio Anual de Actividades 2023",
          description: "Relat\xF3rio completo das actividades realizadas pela ANPERE em 2023. Apresenta estat\xEDsticas de membros, eventos realizados, projectos executados, parcerias estabelecidas e impacto no desenvolvimento do setor de telecomunica\xE7\xF5es.",
          category: "Relat\xF3rio",
          date: "Fevereiro 2024",
          fileUrl: "/api/placeholder/document/relatorio-anual-2023.pdf",
          downloadUrl: null
        },
        {
          title: "C\xF3digo de \xC9tica Profissional dos T\xE9cnicos em Telecomunica\xE7\xF5es",
          description: "Documento que estabelece os princ\xEDpios \xE9ticos e deontol\xF3gicos para o exerc\xEDcio da profiss\xE3o de t\xE9cnico em telecomunica\xE7\xF5es. Define direitos, deveres, responsabilidades e padr\xF5es de conduta profissional.",
          category: "\xC9tica",
          date: "Mar\xE7o 2024",
          fileUrl: "/api/placeholder/document/codigo-etica-2024.pdf",
          downloadUrl: null
        },
        {
          title: "Manual de Boas Pr\xE1ticas em Instala\xE7\xF5es de Telecomunica\xE7\xF5es",
          description: "Guia t\xE9cnico com as melhores pr\xE1ticas para instala\xE7\xE3o, manuten\xE7\xE3o e opera\xE7\xE3o de equipamentos de telecomunica\xE7\xF5es. Inclui normas de seguran\xE7a, procedimentos t\xE9cnicos e recomenda\xE7\xF5es para garantir qualidade e efici\xEAncia.",
          category: "Manual T\xE9cnico",
          date: "Abril 2024",
          fileUrl: "/api/placeholder/document/manual-boas-praticas.pdf",
          downloadUrl: null
        },
        {
          title: "Boletim Informativo - Novidades do Setor Q1 2024",
          description: "Boletim trimestral com as principais novidades, avan\xE7os tecnol\xF3gicos, mudan\xE7as regulamentares e oportunidades no setor de telecomunica\xE7\xF5es. Informa\xE7\xE3o actualizada para manter os profissionais informados sobre tend\xEAncias do mercado.",
          category: "Boletim",
          date: "Abril 2024",
          fileUrl: "/api/placeholder/document/boletim-q1-2024.pdf",
          downloadUrl: null
        }
      ];
      const galleryItems = [
        {
          title: "Confer\xEAncia Nacional 2023 - Cerim\xF3nia de Abertura",
          description: "Momento da cerim\xF3nia de abertura da Confer\xEAncia Nacional de Telecomunica\xE7\xF5es 2023, com a presen\xE7a de autoridades governamentais e l\xEDderes do setor.",
          type: "image",
          date: "Junho 2023",
          category: "Eventos",
          thumbnail: "/lovable-uploads/0194c04c-ec72-4ff9-9fd0-e1db7c6f4ef8.png",
          mediaUrl: null
        },
        {
          title: "Workshop 5G - Demonstra\xE7\xE3o Pr\xE1tica",
          description: "Sess\xE3o pr\xE1tica do workshop sobre tecnologias 5G, onde os participantes puderam experimentar equipamentos de \xFAltima gera\xE7\xE3o.",
          type: "image",
          date: "Maio 2023",
          category: "Forma\xE7\xE3o",
          thumbnail: "/lovable-uploads/4bfb5b81-7f66-44a6-8a90-6b7a85c12c14.png",
          mediaUrl: null
        },
        {
          title: "Reuni\xE3o do Conselho Directivo",
          description: "Reuni\xE3o mensal do conselho directivo da ANPERE para discuss\xE3o de estrat\xE9gias e tomada de decis\xF5es importantes para a associa\xE7\xE3o.",
          type: "image",
          date: "Abril 2023",
          category: "Institucional",
          thumbnail: "/lovable-uploads/f47ac10b-58cc-4372-a567-0e02b2c3d479.png",
          mediaUrl: null
        },
        {
          title: "Cerim\xF3nia de Certifica\xE7\xE3o Profissional",
          description: "Cerim\xF3nia de entrega de certificados aos novos profissionais certificados pela ANPERE, reconhecendo sua compet\xEAncia t\xE9cnica.",
          type: "image",
          date: "Mar\xE7o 2023",
          category: "Certifica\xE7\xE3o",
          thumbnail: "/lovable-uploads/0194c04c-ec72-4ff9-9fd0-e1db7c6f4ef8.png",
          mediaUrl: null
        },
        {
          title: "Visita T\xE9cnica \xE0 Esta\xE7\xE3o Base 5G",
          description: "Visita t\xE9cnica de membros da ANPERE a uma moderna esta\xE7\xE3o base 5G para conhecimento das novas tecnologias implementadas.",
          type: "image",
          date: "Fevereiro 2023",
          category: "Visitas",
          thumbnail: "/lovable-uploads/4bfb5b81-7f66-44a6-8a90-6b7a85c12c14.png",
          mediaUrl: null
        },
        {
          title: "Assembleia Geral Anual 2024",
          description: "Assembleia geral anual da ANPERE com apresenta\xE7\xE3o de relat\xF3rios, aprova\xE7\xE3o de contas e elei\xE7\xF5es para novos cargos directivos.",
          type: "image",
          date: "Janeiro 2024",
          category: "Assembleia",
          thumbnail: "/lovable-uploads/f47ac10b-58cc-4372-a567-0e02b2c3d479.png",
          mediaUrl: null
        }
      ];
      let eventsCount = 0;
      for (const event of events2) {
        const insertedEvent = await storage.createEvent(event);
        if (insertedEvent) {
          eventsCount++;
          console.log(`\u2705 Evento criado: ${event.title}`);
        }
      }
      let publicationsCount = 0;
      for (const publication of publications2) {
        const insertedPublication = await storage.createPublication(publication);
        if (insertedPublication) {
          publicationsCount++;
          console.log(`\u2705 Publica\xE7\xE3o criada: ${publication.title}`);
        }
      }
      let galleryCount = 0;
      for (const galleryItem of galleryItems) {
        const insertedGallery = await storage.createGalleryItem(galleryItem);
        if (insertedGallery) {
          galleryCount++;
          console.log(`\u2705 Item de galeria criado: ${galleryItem.title}`);
        }
      }
      console.log(`\u{1F389} Seed conclu\xEDdo! Criados: ${eventsCount} eventos, ${publicationsCount} publica\xE7\xF5es, ${galleryCount} itens de galeria`);
      res.json({
        success: true,
        message: "Dados de exemplo criados com sucesso!",
        eventsCount,
        publicationsCount,
        galleryCount
      });
    } catch (error) {
      console.error("\u274C Erro no seed:", error);
      res.status(500).json({
        success: false,
        message: "Erro ao criar dados de exemplo",
        error: error.message
      });
    }
  });
  app2.post("/api/contact", async (req, res) => {
    try {
      const { name, email, phone, subject, message } = req.body;
      if (!name || !email || !subject || !message) {
        return res.status(400).json({ error: "Campos obrigat\xF3rios: nome, email, assunto e mensagem" });
      }
      const contactMessage = await storage.createContactMessage({
        name,
        email,
        phone: phone || null,
        subject,
        message
      });
      try {
        console.log(`[POST /api/contact] Criando notifica\xE7\xE3o para mensagem de contato: ${contactMessage.id}`);
        const notification = await storage.createNotification({
          type: "contact_message",
          title: "Nova Mensagem de Contato",
          message: `${name} enviou uma nova mensagem: "${subject}"`,
          link: `/admin/contact-messages`,
          relatedId: contactMessage.id
        });
        console.log(`[POST /api/contact] Notifica\xE7\xE3o criada com sucesso: ${notification.id}`);
      } catch (notificationError) {
        console.error("[POST /api/contact] Erro ao criar notifica\xE7\xE3o para mensagem de contato:", notificationError);
      }
      res.status(201).json({
        success: true,
        message: "Mensagem enviada com sucesso! Entraremos em contacto em breve.",
        id: contactMessage.id
      });
    } catch (error) {
      console.error("Error creating contact message:", error);
      res.status(500).json({ error: "Erro ao enviar mensagem. Tente novamente." });
    }
  });
  app2.get("/api/admin/contact-messages", requireAuth, async (req, res) => {
    try {
      const messages = await storage.getAllContactMessages();
      res.json(messages);
    } catch (error) {
      console.error("Error fetching contact messages:", error);
      res.status(500).json({ error: "Failed to fetch contact messages" });
    }
  });
  app2.get("/api/admin/contact-messages/:id", requireAuth, async (req, res) => {
    try {
      const message = await storage.getContactMessage(req.params.id);
      if (!message) {
        return res.status(404).json({ error: "Contact message not found" });
      }
      res.json(message);
    } catch (error) {
      console.error("Error fetching contact message:", error);
      res.status(500).json({ error: "Failed to fetch contact message" });
    }
  });
  app2.put("/api/admin/contact-messages/:id", requireAuth, async (req, res) => {
    try {
      const message = await storage.updateContactMessage(req.params.id, req.body);
      if (!message) {
        return res.status(404).json({ error: "Contact message not found" });
      }
      res.json(message);
    } catch (error) {
      console.error("Error updating contact message:", error);
      res.status(500).json({ error: "Failed to update contact message" });
    }
  });
  app2.delete("/api/admin/contact-messages/:id", requireAuth, async (req, res) => {
    try {
      const success = await storage.deleteContactMessage(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Contact message not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting contact message:", error);
      res.status(500).json({ error: "Failed to delete contact message" });
    }
  });
  const httpServer = createServer(app2);
  return httpServer;
}

// server/vite.ts
import express2 from "express";
import fs2 from "fs";
import path3 from "path";
import { createServer as createViteServer, createLogger } from "vite";

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path2 from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";
var vite_config_default = defineConfig({
  plugins: [
    react(),
    runtimeErrorOverlay(),
    ...process.env.NODE_ENV !== "production" && process.env.REPL_ID !== void 0 ? [
      await import("@replit/vite-plugin-cartographer").then(
        (m) => m.cartographer()
      )
    ] : []
  ],
  resolve: {
    alias: {
      "@": path2.resolve(import.meta.dirname, "client", "src"),
      "@shared": path2.resolve(import.meta.dirname, "shared"),
      "@assets": path2.resolve(import.meta.dirname, "attached_assets")
    }
  },
  root: path2.resolve(import.meta.dirname, "client"),
  envDir: path2.resolve(import.meta.dirname),
  build: {
    outDir: path2.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true
  },
  server: {
    proxy: {
      "/api": {
        target: "http://localhost:8000",
        changeOrigin: true,
        secure: false
      },
      "/storage": {
        target: "http://localhost:8000",
        changeOrigin: true,
        secure: false
      }
    },
    fs: {
      strict: true,
      deny: ["**/.*"]
    }
  }
});

// server/vite.ts
import { nanoid } from "nanoid";
var viteLogger = createLogger();
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: serverOptions,
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path3.resolve(
        import.meta.dirname,
        "..",
        "client",
        "index.html"
      );
      let template = await fs2.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app2) {
  const distPath = path3.resolve(import.meta.dirname, "public");
  if (!fs2.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(express2.static(distPath));
  app2.use("*", (_req, res) => {
    res.sendFile(path3.resolve(distPath, "index.html"));
  });
}

// server/index.ts
var app = express3();
app.use(express3.json());
app.use(express3.urlencoded({ extended: false }));
var MemoryStore = createMemoryStore(session);
app.use(session({
  store: new MemoryStore({
    checkPeriod: 864e5
    // prune expired entries every 24h
  }),
  secret: process.env.SESSION_SECRET || "development-secret-key",
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === "production",
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1e3
    // 24 hours
  }
}));
app.use((req, res, next) => {
  const start = Date.now();
  const path4 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path4.startsWith("/api")) {
      let logLine = `${req.method} ${path4} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    }
  });
  next();
});
(async () => {
  const server = await registerRoutes(app);
  app.use((err, _req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
  });
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const port = process.env.PORT || 5e3;
  const listenOptions = typeof port === "string" && isNaN(Number(port)) ? { path: port } : { port: Number(port), host: "0.0.0.0" };
  server.listen(listenOptions, () => {
    log(`serving on ${JSON.stringify(listenOptions)}`);
  });
})();
